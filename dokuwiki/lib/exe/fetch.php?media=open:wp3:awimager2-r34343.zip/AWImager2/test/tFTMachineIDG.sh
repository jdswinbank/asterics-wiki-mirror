#!/bin/sh
./runctest.sh tFTMachineIDG

