#!/bin/sh
./runctest.sh tDirtyImage2
