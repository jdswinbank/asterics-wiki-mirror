#!/bin/sh
./runctest.sh tClean2
