#!/bin/sh
./runctest.sh test_flaggers
