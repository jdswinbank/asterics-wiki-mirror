#!/bin/sh
./runctest.sh tApplyBeam
