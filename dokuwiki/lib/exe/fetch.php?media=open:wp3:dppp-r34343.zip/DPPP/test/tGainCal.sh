#!/bin/sh
./runctest.sh tGainCal
