#!/bin/sh
./runctest.sh tPreFlagger
