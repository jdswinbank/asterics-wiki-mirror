#!/bin/sh
./runctest.sh tPredict
