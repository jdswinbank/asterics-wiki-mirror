#!/bin/sh
./runctest.sh tApplyCal
