#!/bin/sh
./runctest.sh tPSet
