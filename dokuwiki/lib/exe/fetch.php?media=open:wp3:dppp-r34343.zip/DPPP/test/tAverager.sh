#!/bin/sh
./runctest.sh tAverager
