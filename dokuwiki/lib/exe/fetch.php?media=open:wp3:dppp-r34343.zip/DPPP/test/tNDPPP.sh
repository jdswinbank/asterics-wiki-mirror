#!/bin/sh
./runctest.sh tNDPPP
