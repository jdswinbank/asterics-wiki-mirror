#!/bin/sh
./runctest.sh tUVWFlagger
