#!/bin/sh
./runctest.sh tMedFlagger
