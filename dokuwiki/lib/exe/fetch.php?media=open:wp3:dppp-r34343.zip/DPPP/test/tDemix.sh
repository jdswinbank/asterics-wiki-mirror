#!/bin/sh
./runctest.sh tDemix
