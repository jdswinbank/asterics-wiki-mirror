#!/bin/sh
./runctest.sh tmwflagger
