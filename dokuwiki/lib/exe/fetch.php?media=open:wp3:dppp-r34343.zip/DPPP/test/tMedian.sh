#!/bin/sh
./runctest.sh tMedian
