#!/bin/sh
./runctest.sh tMirror
