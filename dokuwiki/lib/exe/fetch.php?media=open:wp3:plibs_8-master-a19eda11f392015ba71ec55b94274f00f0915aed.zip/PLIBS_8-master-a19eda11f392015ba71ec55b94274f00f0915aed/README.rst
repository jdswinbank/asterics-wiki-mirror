This library contains usefull libraries and programs for CTA and ASTERICS projects

Project installation :
======================

$> git clone https://gitlab.in2p3.fr/paubert/PLIBS_8.git

$> cd PLIB_8

$> ./install.sh

=========================
**1. Module PLIB_8_BASE**
=========================

========================================
**Module PLIB_8_BASE/Library PLIB_CORE**
========================================


PAlloc
======

To allocate aligned tables.

PCompress
=========

To compress data.

PConfig
=======

To read configuration files.

PDebug
======

To debug program with a very easy way. ("Contains the most usefull function in the world", Gilles Maurin)

PDictionnary
============

Sort data with string keys.

PGenerator
==========

Contains a c++ class generator.

PGraph
======

To create graphs.

PLists
======

Contains, list and stuff to put data togethers.

PProgress
=========

Contains progress bar in ternimal mode with remaning time calculation.

PSaver
======

Contains function to load and save data (struct, class) in binary files.

PTimer
======

Contains functions to get the time of a process in cycles.

PTree
=====

Contains tree classes and a very powerfull sort function.

TESTS
=====

Contains tests for the PLIB_CORE library.


========================================
**Module PLIB_8_BASE/Library PLIB_MATH**
========================================


PChecks
=======

Contains abstract functions to perform unit tests.

PDebug
======

Contains stuff to debug your programs. It's similar to  the PDebug directory of PLIB_CORE but this one allows you to create plots, and histograms 1d and 2d.

PFormula
========

Contains functions to parse a given formula in a graph.

PFunctions
==========

Contains functions classes like x, xy functions, histograms 1d and 2d, and class to plot point cloud with error on each bin.

PGnuplot
========

Contains usefull function to call gnuplot and create graph easly.

PMathAlgebra
============

Contains functions to change coodinates, get the minimum and maximum values in a list or a table of abstract types. And other function to calculate distribution parameters like mean, rms...

- POperands : Contains expression template definition of Vectors (1d, 2d, 3d, nd), Matrices 3x3, 4x4, nxn)
 - abstractFunction : Contains abstract function for abs, equal, sin, cos, tan, exp, pow, sqrt...
- POperators : Contains all expression template operator +, -, *, /, for all class in the POperands directory.

PRandom
=======

Contains random number generator on several known distribution like Uniform, Gauss, Poisson.

TESTS
=====

Contains tests for all the PLIB_MATH library.


==========================================
**Module PLIB_8_BASE/Library PLIB_THREAD**
==========================================

Contains function to pin a thread on a CPU core.

TESTS
=====

Contains tests for all the PLIB_THREAD library.

=============================================
**Module PLIB_8_BASE/Library PLIB_VECTORIZE**
=============================================

Contains optimized function to perform fast reduction, gemm, gemv, sxpy, or mobiles move calculation.

TESTS
=====

Contains tests for all the PLIB_THREAD library.

==========================
**2. Module PLIB_8_UTILS**
==========================


BashCompletion
==============

Contains bash completion config.


PBASH_COMPLETION_GENERATOR
==========================

Program to generate bash completion.


PDataGenerator
==============

Program to generate a efficent data format for High Performance Computing (HPC).


PFILE_GENERATOR
===============

Programs to generate c++ classes (template or not).


PFILE_STAT
==========

Does statistics on a file.


PFILE_STR_COUNTER
=================

Counts occurence of a patern in a file.


PGENERATOR_HEADER_SOURCE
========================

Generates pair of header (.h), source (.cpp).


PGIT
====

Does git call on multiple repositories.


PGREP
=====

Returns the begining of the lines that contains patern we are looking for.


PHISTOGRAM2D
============

Creates 2d histogram with input file.


PHISTOGRAMD
===========

Creates 1d histogram with input file.



PLIB_UNINSTALL
==============

Uninstalls PLIBS_8.



PMAIN_CREATOR
=============

Generates a main.cpp file to embed the given basic function callable like a program. And generate the argument parsing. And compile the program if you ask for.



PNUMBER_GENERATOR
=================

Generates a file with a given mathmatic expression.



PParserGenerator
================

Generates language parser (not finished yet).


PREPLACE_STR_IN_FILE
====================

Replaces string in a file.





