#!/bin/bash

git config alias.pull '!git pull && git submodule update --init --recursive'


