/***************************************
	Auteur : Pierre Aubert
	Mail : aubertp7@gmail.com
	Licence : CeCILL-C
****************************************/

#include <iostream>

int main(int argc, char **argv) {
	std::cout << "Version PLIBS " << PLIBS_VERSION << std::endl;
}


