package cz.metacentrum.perun.core.api.exceptions.rt;

@SuppressWarnings("serial")
public class ServicesPackageExistsRuntimeException extends EntityExistsRuntimeException {

	public ServicesPackageExistsRuntimeException() {
		super();
	}

	public ServicesPackageExistsRuntimeException(Throwable cause) {
		super(cause);
	}


}
