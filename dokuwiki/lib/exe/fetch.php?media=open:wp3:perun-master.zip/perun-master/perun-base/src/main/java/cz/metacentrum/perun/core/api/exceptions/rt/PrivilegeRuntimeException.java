package cz.metacentrum.perun.core.api.exceptions.rt;

@SuppressWarnings("serial")
public class PrivilegeRuntimeException extends PerunRuntimeException {

	public PrivilegeRuntimeException() {
		super();
	}

	public PrivilegeRuntimeException(Throwable cause) {
		super(cause);
	}
}
