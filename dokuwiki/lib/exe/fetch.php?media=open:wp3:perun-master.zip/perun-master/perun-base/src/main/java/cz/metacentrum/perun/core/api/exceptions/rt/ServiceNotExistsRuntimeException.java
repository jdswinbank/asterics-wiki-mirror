package cz.metacentrum.perun.core.api.exceptions.rt;

@SuppressWarnings("serial")
public class ServiceNotExistsRuntimeException extends EntityNotExistsRuntimeException {

	public ServiceNotExistsRuntimeException() {
		super();
	}

	public ServiceNotExistsRuntimeException(Throwable cause) {
		super(cause);
	}


}
