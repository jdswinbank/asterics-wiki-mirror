package cz.metacentrum.perun.core.api.exceptions.rt;

@SuppressWarnings("serial")
public class GroupNotExistsRuntimeException extends EntityNotExistsRuntimeException {

	public GroupNotExistsRuntimeException() {
		super();
	}

	public GroupNotExistsRuntimeException(Throwable cause) {
		super(cause);
	}


}
