package cz.metacentrum.perun.core.api.exceptions.rt;

@SuppressWarnings("serial")
public class DestinationAlreadyRemovedRuntimeException extends PerunRuntimeException {

	public DestinationAlreadyRemovedRuntimeException() {
		super();
	}

	public DestinationAlreadyRemovedRuntimeException(Throwable cause) {
		super(cause);
	}


}
