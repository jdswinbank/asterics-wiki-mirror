package cz.metacentrum.perun.core.api.exceptions.rt;

@SuppressWarnings("serial")
public class ParentGroupNotExistsRuntimeException extends EntityNotExistsRuntimeException {

	public ParentGroupNotExistsRuntimeException() {
		super();
	}

	public ParentGroupNotExistsRuntimeException(Throwable cause) {
		super(cause);
	}


}
