package cz.metacentrum.perun.core.api.exceptions.rt;

@SuppressWarnings("serial")
public class OwnerAlreadyRemovedRuntimeException extends PerunRuntimeException {

	public OwnerAlreadyRemovedRuntimeException() {
		super();
	}

	public OwnerAlreadyRemovedRuntimeException(Throwable cause) {
		super(cause);
	}


}
