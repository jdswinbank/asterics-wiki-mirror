package cz.metacentrum.perun.core.api.exceptions.rt;

@SuppressWarnings("serial")
public class OwnerAlreadyAssignedRuntimeException extends PerunRuntimeException {

	public OwnerAlreadyAssignedRuntimeException() {
		super();
	}

	public OwnerAlreadyAssignedRuntimeException(Throwable cause) {
		super(cause);
	}


}
