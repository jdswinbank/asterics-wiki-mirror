configuration = {
    LOADER_IMAGE: '/apps-include/img/loader_white-bg.gif',
    TOP_FOLDER: 'apps'
};
