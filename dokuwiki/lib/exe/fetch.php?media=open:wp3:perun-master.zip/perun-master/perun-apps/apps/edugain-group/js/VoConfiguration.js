voConfiguration = {
    SHORT_NAME: "edugain_group",
    TEMPLATE_NAME: "template"
};