package cz.metacentrum.perun.core.entry;

import java.util.ArrayList;
import java.util.List;

import cz.metacentrum.perun.core.api.exceptions.DestinationNotExistsException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cz.metacentrum.perun.core.api.AuthzResolver;
import cz.metacentrum.perun.core.api.ContactGroup;
import cz.metacentrum.perun.core.api.FacilitiesManager;
import cz.metacentrum.perun.core.api.Facility;
import cz.metacentrum.perun.core.api.Group;
import cz.metacentrum.perun.core.api.Host;
import cz.metacentrum.perun.core.api.Member;
import cz.metacentrum.perun.core.api.Owner;
import cz.metacentrum.perun.core.api.PerunBean;
import cz.metacentrum.perun.core.api.PerunSession;
import cz.metacentrum.perun.core.api.Resource;
import cz.metacentrum.perun.core.api.RichFacility;
import cz.metacentrum.perun.core.api.RichResource;
import cz.metacentrum.perun.core.api.RichUser;
import cz.metacentrum.perun.core.api.Role;
import cz.metacentrum.perun.core.api.SecurityTeam;
import cz.metacentrum.perun.core.api.Service;
import cz.metacentrum.perun.core.api.User;
import cz.metacentrum.perun.core.api.Vo;
import cz.metacentrum.perun.core.api.exceptions.AlreadyAdminException;
import cz.metacentrum.perun.core.api.exceptions.FacilityAlreadyRemovedException;
import cz.metacentrum.perun.core.api.exceptions.FacilityContactNotExistsException;
import cz.metacentrum.perun.core.api.exceptions.FacilityExistsException;
import cz.metacentrum.perun.core.api.exceptions.FacilityNotExistsException;
import cz.metacentrum.perun.core.api.exceptions.GroupAlreadyRemovedException;
import cz.metacentrum.perun.core.api.exceptions.GroupAlreadyRemovedFromResourceException;
import cz.metacentrum.perun.core.api.exceptions.GroupNotAdminException;
import cz.metacentrum.perun.core.api.exceptions.GroupNotExistsException;
import cz.metacentrum.perun.core.api.exceptions.HostAlreadyRemovedException;
import cz.metacentrum.perun.core.api.exceptions.HostExistsException;
import cz.metacentrum.perun.core.api.exceptions.HostNotExistsException;
import cz.metacentrum.perun.core.api.exceptions.InternalErrorException;
import cz.metacentrum.perun.core.api.exceptions.MemberNotExistsException;
import cz.metacentrum.perun.core.api.exceptions.OwnerAlreadyAssignedException;
import cz.metacentrum.perun.core.api.exceptions.OwnerAlreadyRemovedException;
import cz.metacentrum.perun.core.api.exceptions.OwnerNotExistsException;
import cz.metacentrum.perun.core.api.exceptions.PrivilegeException;
import cz.metacentrum.perun.core.api.exceptions.RelationExistsException;
import cz.metacentrum.perun.core.api.exceptions.ResourceAlreadyRemovedException;
import cz.metacentrum.perun.core.api.exceptions.SecurityTeamAlreadyAssignedException;
import cz.metacentrum.perun.core.api.exceptions.SecurityTeamNotAssignedException;
import cz.metacentrum.perun.core.api.exceptions.SecurityTeamNotExistsException;
import cz.metacentrum.perun.core.api.exceptions.ServiceNotExistsException;
import cz.metacentrum.perun.core.api.exceptions.UserNotAdminException;
import cz.metacentrum.perun.core.api.exceptions.UserNotExistsException;
import cz.metacentrum.perun.core.api.exceptions.VoNotExistsException;
import cz.metacentrum.perun.core.api.exceptions.WrongAttributeAssignmentException;
import cz.metacentrum.perun.core.api.exceptions.WrongAttributeValueException;
import cz.metacentrum.perun.core.api.exceptions.WrongPatternException;
import cz.metacentrum.perun.core.api.exceptions.WrongReferenceAttributeValueException;
import cz.metacentrum.perun.core.api.exceptions.rt.InternalErrorRuntimeException;
import cz.metacentrum.perun.core.bl.FacilitiesManagerBl;
import cz.metacentrum.perun.core.bl.PerunBl;
import cz.metacentrum.perun.core.impl.AuthzRoles;
import cz.metacentrum.perun.core.impl.Utils;
import cz.metacentrum.perun.core.implApi.FacilitiesManagerImplApi;
import java.util.Iterator;

/**
 *
 * @author Slavek Licehammer glory@ics.muni.cz
 */
public class FacilitiesManagerEntry implements FacilitiesManager {

	final static Logger log = LoggerFactory.getLogger(FacilitiesManagerEntry.class);

	private FacilitiesManagerBl facilitiesManagerBl;
	private PerunBl perunBl;

	public FacilitiesManagerEntry(PerunBl perunBl) {
		this.perunBl = perunBl;
		this.facilitiesManagerBl = perunBl.getFacilitiesManagerBl();
	}

	public FacilitiesManagerEntry() {}

	public FacilitiesManagerImplApi getFacilitiesManagerImpl() {
		throw new InternalErrorRuntimeException("Unsupported method!");
	}

	public Facility getFacilityById(PerunSession sess, int id) throws InternalErrorException, FacilityNotExistsException, PrivilegeException {
		Utils.checkPerunSession(sess);

		Facility facility = getFacilitiesManagerBl().getFacilityById(sess, id);

		// Authorization
		if (!AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN, facility) &&
				!AuthzResolver.isAuthorized(sess, Role.ENGINE) &&
				!AuthzResolver.isAuthorized(sess, Role.RPC)) {
			throw new PrivilegeException(sess, "getFacilityById");
				}

		return facility;
	}

	public Facility getFacilityByName(PerunSession sess, String name) throws InternalErrorException, FacilityNotExistsException, PrivilegeException {
		Utils.checkPerunSession(sess);
		Utils.notNull(name, "name");

		Facility facility = getFacilitiesManagerBl().getFacilityByName(sess, name);

		// Authorization
		if (!AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN, facility) &&
				!AuthzResolver.isAuthorized(sess, Role.ENGINE) &&
				!AuthzResolver.isAuthorized(sess, Role.RPC)) {
			throw new PrivilegeException(sess, "getFacilityByName");
				}

		return facility;
	}
	
	public List<RichFacility> getRichFacilities(PerunSession sess) throws InternalErrorException, PrivilegeException {
		Utils.checkPerunSession(sess);

		// Perun admin can see everything
		if (AuthzResolver.isAuthorized(sess, Role.PERUNADMIN)) {
			return getFacilitiesManagerBl().getRichFacilities(sess);
		} else if (AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN)) {
			// Cast complementary object to Facility
			List<Facility> facilities = new ArrayList<Facility>();
			for (PerunBean facility: AuthzResolver.getComplementaryObjectsForRole(sess, Role.FACILITYADMIN, Facility.class)) {
				facilities.add((Facility) facility);
			}
			//Now I create list of richFacilities from facilities
			return getFacilitiesManagerBl().getRichFacilities(sess, facilities);
		} else {
			throw new PrivilegeException(sess, "getRichFacilities");
		}
	}
	
	public List<Facility> getFacilitiesByDestination(PerunSession sess, String destination) throws InternalErrorException, FacilityNotExistsException, PrivilegeException {
		Utils.checkPerunSession(sess);
		Utils.notNull(destination, "destination");

		List<Facility> facilities = getFacilitiesManagerBl().getFacilitiesByDestination(sess, destination);

		// Authorization
		if (!AuthzResolver.isAuthorized(sess, Role.ENGINE) &&
				!AuthzResolver.isAuthorized(sess, Role.RPC)) {
			throw new PrivilegeException(sess, "getFacilitiesByDestination");
				}

		return facilities;
	}

	public int getFacilitiesCount(PerunSession sess) throws InternalErrorException, PrivilegeException {
		Utils.checkPerunSession(sess);

		// Authorization
		if (!AuthzResolver.isAuthorized(sess, Role.PERUNADMIN)) {
			throw new PrivilegeException(sess, "getFacilitiesCount");
		}

		return getFacilitiesManagerBl().getFacilitiesCount(sess);
	}

	public List<Facility> getFacilities(PerunSession sess) throws InternalErrorException, PrivilegeException {
		Utils.checkPerunSession(sess);

		// Perun admin can see everything
		if (AuthzResolver.isAuthorized(sess, Role.PERUNADMIN)) {
			return getFacilitiesManagerBl().getFacilities(sess);
		} else if (AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN)) {
			// Cast complementary object to Facility
			List<Facility> facilities = new ArrayList<Facility>();
			for (PerunBean facility: AuthzResolver.getComplementaryObjectsForRole(sess, Role.FACILITYADMIN, Facility.class)) {
				facilities.add((Facility) facility);
			}
			return facilities;
		} else {
			throw new PrivilegeException(sess, "getFacilities");
		}
	}

	public List<Owner> getOwners(PerunSession sess, Facility facility) throws InternalErrorException, PrivilegeException, FacilityNotExistsException {
		Utils.checkPerunSession(sess);

		// Authorization
		if (!AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN, facility) &&
				!AuthzResolver.isAuthorized(sess, Role.ENGINE)) {
			throw new PrivilegeException(sess, "getOwners");
				}

		getFacilitiesManagerBl().checkFacilityExists(sess, facility);

		return getFacilitiesManagerBl().getOwners(sess, facility);
	}

	public void setOwners(PerunSession sess, Facility facility, List<Owner> owners) throws InternalErrorException, PrivilegeException, FacilityNotExistsException, OwnerNotExistsException {
		Utils.checkPerunSession(sess);

		// Authorization
		if (!AuthzResolver.isAuthorized(sess, Role.PERUNADMIN)) {
			throw new PrivilegeException(sess, "setOwners");
		}

		getFacilitiesManagerBl().checkFacilityExists(sess, facility);
		Utils.notNull(owners, "owners");
		for (Owner owner: owners) {
			getPerunBl().getOwnersManagerBl().checkOwnerExists(sess, owner);
		}

		getFacilitiesManagerBl().setOwners(sess, facility, owners);
	}

	public void addOwner(PerunSession sess, Facility facility, Owner owner) throws InternalErrorException, PrivilegeException, OwnerNotExistsException, FacilityNotExistsException, OwnerAlreadyAssignedException {
		Utils.checkPerunSession(sess);

		// Authorization
		if (!AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN, facility)) {
			throw new PrivilegeException(sess, "addOwner");
		}

		getFacilitiesManagerBl().checkFacilityExists(sess, facility);
		getPerunBl().getOwnersManagerBl().checkOwnerExists(sess, owner);

		getFacilitiesManagerBl().addOwner(sess, facility, owner);
	}

	public void removeOwner(PerunSession sess, Facility facility, Owner owner) throws InternalErrorException, PrivilegeException, OwnerNotExistsException, FacilityNotExistsException, OwnerAlreadyRemovedException {
		Utils.checkPerunSession(sess);

		// Authorization
		if (!AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN, facility)) {
			throw new PrivilegeException(sess, "removeOwner");
		}
		getFacilitiesManagerBl().checkFacilityExists(sess, facility);
		getPerunBl().getOwnersManagerBl().checkOwnerExists(sess, owner);

		getFacilitiesManagerBl().removeOwner(sess, facility, owner);
	}

	public void copyOwners(PerunSession sess, Facility sourceFacility, Facility destinationFacility) throws InternalErrorException, FacilityNotExistsException, PrivilegeException {
		Utils.checkPerunSession(sess);

		getFacilitiesManagerBl().checkFacilityExists(sess, sourceFacility);
		getFacilitiesManagerBl().checkFacilityExists(sess, destinationFacility);

		// Authorization - facility admin of the both facilities required
		if (!AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN, sourceFacility)) {
			throw new PrivilegeException(sess, "copyOwners");
		}
		if (!AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN, destinationFacility)) {
			throw new PrivilegeException(sess, "copyOwners");
		}

		getFacilitiesManagerBl().copyOwners(sess, sourceFacility, destinationFacility);
	}

	public List<Vo> getAllowedVos(PerunSession sess, Facility facility) throws InternalErrorException, PrivilegeException, FacilityNotExistsException {
		Utils.checkPerunSession(sess);

		// Authorization
		if (!AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN, facility)) {
			throw new PrivilegeException(sess, "getAlloewdVos");
		}

		getFacilitiesManagerBl().checkFacilityExists(sess, facility);

		return getFacilitiesManagerBl().getAllowedVos(sess, facility);

	}

	public List<Group> getAllowedGroups(PerunSession perunSession, Facility facility, Vo specificVo, Service specificService) throws InternalErrorException, PrivilegeException, FacilityNotExistsException, ServiceNotExistsException, VoNotExistsException {
		Utils.checkPerunSession(perunSession);

		//Authrorization
		if (!AuthzResolver.isAuthorized(perunSession, Role.FACILITYADMIN, facility)) {
			throw new PrivilegeException(perunSession, "getAlloewdGroups");
		}

		getFacilitiesManagerBl().checkFacilityExists(perunSession, facility);
		if(specificVo != null) getPerunBl().getVosManagerBl().checkVoExists(perunSession, specificVo);
		if(specificService != null) getPerunBl().getServicesManagerBl().checkServiceExists(perunSession, specificService);

		return getFacilitiesManagerBl().getAllowedGroups(perunSession, facility, specificVo, specificService);
	}

	public List<User> getAllowedUsers(PerunSession sess, Facility facility) throws InternalErrorException, PrivilegeException, FacilityNotExistsException{
		Utils.checkPerunSession(sess);

		// Authorization
		if (!AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN, facility)) {
			throw new PrivilegeException(sess, "getAllowedUsers");
		}

		getFacilitiesManagerBl().checkFacilityExists(sess, facility);

		return getFacilitiesManagerBl().getAllowedUsers(sess, facility);
	}

	public List<User> getAllowedUsers(PerunSession sess, Facility facility, Vo specificVo, Service specificService) throws InternalErrorException, PrivilegeException, FacilityNotExistsException, ServiceNotExistsException, VoNotExistsException {
		Utils.checkPerunSession(sess);

		// Authorization
		if (!AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN, facility)) {
			throw new PrivilegeException(sess, "getAllowedUsers");
		}

		getFacilitiesManagerBl().checkFacilityExists(sess, facility);
		if(specificVo != null) getPerunBl().getVosManagerBl().checkVoExists(sess, specificVo);
		if(specificService != null) getPerunBl().getServicesManagerBl().checkServiceExists(sess, specificService);

		return getFacilitiesManagerBl().getAllowedUsers(sess, facility, specificVo, specificService);
	}

	public List<Resource> getAssignedResources(PerunSession sess, Facility facility) throws InternalErrorException, PrivilegeException, FacilityNotExistsException {
		Utils.checkPerunSession(sess);

		// Authorization
		if (!AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN, facility) &&
		    !AuthzResolver.isAuthorized(sess, Role.ENGINE)) {
			throw new PrivilegeException(sess, "getAssignedResources");
		}

		getFacilitiesManagerBl().checkFacilityExists(sess, facility);

		return getFacilitiesManagerBl().getAssignedResources(sess, facility);
	}

	public List<RichResource> getAssignedRichResources(PerunSession sess, Facility facility) throws InternalErrorException, PrivilegeException, FacilityNotExistsException {
		Utils.checkPerunSession(sess);

		// Authorization
		if (!AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN, facility)) {
			throw new PrivilegeException(sess, "getAssignedRichResources");
		}

		getFacilitiesManagerBl().checkFacilityExists(sess, facility);

		return getFacilitiesManagerBl().getAssignedRichResources(sess, facility);

	}

	public Facility createFacility(PerunSession sess, Facility facility) throws InternalErrorException, PrivilegeException, FacilityExistsException {
		Utils.checkPerunSession(sess);

		// Authorization
		if (!AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN)) {
			throw new PrivilegeException(sess, "createFacility");
		}

		return getFacilitiesManagerBl().createFacility(sess, facility);
	}

	public void deleteFacility(PerunSession sess, Facility facility) throws InternalErrorException, RelationExistsException, FacilityNotExistsException, PrivilegeException, FacilityAlreadyRemovedException, HostAlreadyRemovedException, GroupAlreadyRemovedException, ResourceAlreadyRemovedException, GroupAlreadyRemovedFromResourceException {
		Utils.checkPerunSession(sess);

		// Authorization
		if (!AuthzResolver.isAuthorized(sess, Role.PERUNADMIN)) {
			throw new PrivilegeException(sess, "deleteFacility");
		}

		getFacilitiesManagerBl().checkFacilityExists(sess, facility);

		getFacilitiesManagerBl().deleteFacility(sess, facility);
	}

	public Facility updateFacility(PerunSession sess, Facility facility) throws FacilityNotExistsException, InternalErrorException, PrivilegeException {
		Utils.checkPerunSession(sess);
		getFacilitiesManagerBl().checkFacilityExists(sess, facility);
		Utils.notNull(facility, "facility");
		Utils.notNull(facility.getName(), "facility.name");

		// Authorization
		if (!AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN, facility)) {
			throw new PrivilegeException(sess, "updateFacility");
		}

		return getFacilitiesManagerBl().updateFacility(sess, facility);
	}

	public List<Facility> getOwnerFacilities(PerunSession sess, Owner owner) throws InternalErrorException, OwnerNotExistsException, PrivilegeException {
		Utils.checkPerunSession(sess);

		// Authorization
		if (!AuthzResolver.isAuthorized(sess, Role.PERUNADMIN)) {
			throw new PrivilegeException(sess, "getOwnerFacilities");
		}

		getPerunBl().getOwnersManagerBl().checkOwnerExists(sess, owner);

		return getFacilitiesManagerBl().getOwnerFacilities(sess, owner);
	}

	public List<Facility> getAssignedFacilities(PerunSession sess, Group group) throws InternalErrorException, PrivilegeException, GroupNotExistsException {
		Utils.checkPerunSession(sess);
		getPerunBl().getGroupsManagerBl().checkGroupExists(sess, group);

		// Authorization
		if (!AuthzResolver.isAuthorized(sess, Role.PERUNADMIN) &&
				!AuthzResolver.isAuthorized(sess, Role.VOADMIN, group) &&
				!AuthzResolver.isAuthorized(sess, Role.VOOBSERVER, group) &&
				!AuthzResolver.isAuthorized(sess, Role.VOOBSERVER, group) &&
				!AuthzResolver.isAuthorized(sess, Role.GROUPADMIN, group) &&
				!AuthzResolver.isAuthorized(sess, Role.ENGINE)) {
			throw new PrivilegeException(sess, "getAssignedFacilities");
				}

		return getFacilitiesManagerBl().getAssignedFacilities(sess, group);
	}

	public List<Facility> getAssignedFacilities(PerunSession sess, Member member) throws InternalErrorException, PrivilegeException, MemberNotExistsException {
		Utils.checkPerunSession(sess);
		getPerunBl().getMembersManagerBl().checkMemberExists(sess, member);

		// Authorization
		if (!AuthzResolver.isAuthorized(sess, Role.SELF, member) &&
				!AuthzResolver.isAuthorized(sess, Role.ENGINE)) {
			throw new PrivilegeException(sess, "getAssignedFacilities");
				}

		return getFacilitiesManagerBl().getAssignedFacilities(sess, member);
	}

	public List<Facility> getAssignedFacilities(PerunSession sess, User user) throws InternalErrorException, PrivilegeException, UserNotExistsException {
		Utils.checkPerunSession(sess);
		getPerunBl().getUsersManagerBl().checkUserExists(sess, user);

		// Authorization
		if (!AuthzResolver.isAuthorized(sess, Role.SELF, user) &&
				!AuthzResolver.isAuthorized(sess, Role.ENGINE)) {
			throw new PrivilegeException(sess, "getAssignedFacilities");
				}

		return getFacilitiesManagerBl().getAssignedFacilities(sess, user);
	}

	public List<Facility> getAssignedFacilities(PerunSession sess, Service service) throws InternalErrorException, PrivilegeException, ServiceNotExistsException {
		Utils.checkPerunSession(sess);
		getPerunBl().getServicesManagerBl().checkServiceExists(sess, service);

		// Authorization
		if (!AuthzResolver.isAuthorized(sess, Role.ENGINE)) {
			throw new PrivilegeException(sess, "getAssignedFacilities");
		}

		return getFacilitiesManagerBl().getAssignedFacilities(sess, service);
	}

	public List<Facility> getAssignedFacilities(PerunSession sess, SecurityTeam securityTeam) throws InternalErrorException, PrivilegeException, SecurityTeamNotExistsException {
		Utils.checkPerunSession(sess);
		getPerunBl().getSecurityTeamsManagerBl().checkSecurityTeamExists(sess, securityTeam);

		// Authorization
		if (!AuthzResolver.isAuthorized(sess, Role.SECURITYADMIN, securityTeam)) {
			throw new PrivilegeException(sess, "getAssignedFacilities");
		}

		return getFacilitiesManagerBl().getAssignedFacilities(sess, securityTeam);
	}

	/**
	 * Gets the facilitiesManagerBl for this instance.
	 *
	 * @return The facilitiesManagerBl.
	 */
	public FacilitiesManagerBl getFacilitiesManagerBl() {
		return this.facilitiesManagerBl;
	}

	/**
	 * Sets the perunBl.
	 *
	 * @param perunBl The perunBl.
	 */
	public void setPerunBl(PerunBl perunBl) {
		this.perunBl = perunBl;
	}

	public List<Host> getHosts(PerunSession sess, Facility facility) throws FacilityNotExistsException, InternalErrorException, PrivilegeException {
		Utils.checkPerunSession(sess);
		getFacilitiesManagerBl().checkFacilityExists(sess, facility);

		//TODO authorization

		return getFacilitiesManagerBl().getHosts(sess, facility);
	}

	public int getHostsCount(PerunSession sess, Facility facility) throws FacilityNotExistsException, InternalErrorException, PrivilegeException {
		Utils.checkPerunSession(sess);

		getFacilitiesManagerBl().checkFacilityExists(sess, facility);
		// Authorization
		if (!AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN, facility)) {
			throw new PrivilegeException(sess, "getHostsCount");
		}

		return getFacilitiesManagerBl().getHostsCount(sess, facility);
	}

	public List<Host> addHosts(PerunSession sess, List<Host> hosts, Facility facility) throws FacilityNotExistsException, InternalErrorException, PrivilegeException, HostExistsException {
		Utils.checkPerunSession(sess);

		getFacilitiesManagerBl().checkFacilityExists(sess, facility);
		// Authorization
		if (!AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN, facility)) {
			throw new PrivilegeException(sess, "addHosts");
		}

		Utils.notNull(hosts, "hosts");

		for(Host host: hosts) {

			List<Facility> facilitiesByHostname = getFacilitiesManagerBl().getFacilitiesByHostName(sess, host.getHostname());
			List<Facility> facilitiesByDestination = getFacilitiesManagerBl().getFacilitiesByDestination(sess, host.getHostname());

			if(facilitiesByHostname.isEmpty() && facilitiesByDestination.isEmpty()) {
				continue;
			}
			if(!facilitiesByHostname.isEmpty()) {
				boolean hasRight = false;
				for(Facility f: facilitiesByHostname) {
					if(AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN, f)) {
						hasRight = true;
						break;
					}
				}
				if(hasRight) continue;
			}
			if(!facilitiesByDestination.isEmpty()) {
				boolean hasRight = false;
				for(Facility f: facilitiesByDestination) {
					if(AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN, f)) {
						hasRight = true;
						break;
					}
				}
				if(hasRight) continue;
			}

			throw new PrivilegeException(sess, "You can't add host " + host + ", because you don't have privileges to use this hostName");
		}

		return getFacilitiesManagerBl().addHosts(sess, hosts, facility);
	}

	public List<Host> addHosts(PerunSession sess, Facility facility, List<String> hosts) throws FacilityNotExistsException, InternalErrorException, PrivilegeException, HostExistsException, WrongPatternException {
		Utils.checkPerunSession(sess);

		getFacilitiesManagerBl().checkFacilityExists(sess, facility);
		// Authorization
		if (!AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN, facility)) {
			throw new PrivilegeException(sess, "addHosts");
		}

		Utils.notNull(hosts, "hosts");

		List<Host> addedHosts = getFacilitiesManagerBl().addHosts(sess, facility, hosts);

		for(Host host: addedHosts) {

			List<Facility> facilitiesByHostname = getFacilitiesManagerBl().getFacilitiesByHostName(sess, host.getHostname());
			List<Facility> facilitiesByDestination = getFacilitiesManagerBl().getFacilitiesByDestination(sess, host.getHostname());

			if(facilitiesByHostname.isEmpty() && facilitiesByDestination.isEmpty()) {
				continue;
			}
			if(!facilitiesByHostname.isEmpty()) {
				boolean hasRight = false;
				for(Facility f: facilitiesByHostname) {
					if(AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN, f)) {
						hasRight = true;
						break;
					}
				}
				if(hasRight) continue;
			}
			if(!facilitiesByDestination.isEmpty()) {
				boolean hasRight = false;
				for(Facility f: facilitiesByDestination) {
					if(AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN, f)) {
						hasRight = true;
						break;
					}
				}
				if(hasRight) continue;
			}

			throw new PrivilegeException(sess, "You can't add host " + host + ", because you don't have privileges to use this hostName");
		}

		return addedHosts;
	}

	public void removeHosts(PerunSession sess, List<Host> hosts, Facility facility) throws FacilityNotExistsException, InternalErrorException, PrivilegeException, HostAlreadyRemovedException {
		Utils.checkPerunSession(sess);

		getFacilitiesManagerBl().checkFacilityExists(sess, facility);
		// Authorization
		if (!AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN, facility)) {
			throw new PrivilegeException(sess, "removeHosts");
		}

		Utils.notNull(hosts, "hosts");

		getFacilitiesManagerBl().removeHosts(sess, hosts, facility);
	}

	public void addAdmin(PerunSession sess, Facility facility, User user) throws InternalErrorException, FacilityNotExistsException, UserNotExistsException, PrivilegeException, AlreadyAdminException {
		Utils.checkPerunSession(sess);

		getFacilitiesManagerBl().checkFacilityExists(sess, facility);
		getPerunBl().getUsersManagerBl().checkUserExists(sess, user);

		// Authorization
		if (!AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN, facility)) {
			throw new PrivilegeException(sess, "addAdmin");
		}

		getFacilitiesManagerBl().addAdmin(sess, facility, user);
	}

	@Override
	public void addAdmin(PerunSession sess, Facility facility, Group group) throws InternalErrorException, FacilityNotExistsException, GroupNotExistsException, PrivilegeException, AlreadyAdminException {
		Utils.checkPerunSession(sess);

		getFacilitiesManagerBl().checkFacilityExists(sess, facility);
		getPerunBl().getGroupsManagerBl().checkGroupExists(sess, group);

		// Authorization
		if (!AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN, facility)) {
			throw new PrivilegeException(sess, "addAdmin");
		}

		getFacilitiesManagerBl().addAdmin(sess, facility, group);
	}

	public void removeAdmin(PerunSession sess, Facility facility, User user) throws InternalErrorException, FacilityNotExistsException, UserNotExistsException, PrivilegeException, UserNotAdminException {
		Utils.checkPerunSession(sess);

		getFacilitiesManagerBl().checkFacilityExists(sess, facility);
		getPerunBl().getUsersManagerBl().checkUserExists(sess, user);
		// Authorization
		if (!AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN, facility)) {
			throw new PrivilegeException(sess, "deleteAdmin");
		}

		getFacilitiesManagerBl().removeAdmin(sess, facility, user);

	}

	@Override
	public void removeAdmin(PerunSession sess, Facility facility, Group group) throws InternalErrorException, FacilityNotExistsException, GroupNotExistsException, PrivilegeException, GroupNotAdminException {
		Utils.checkPerunSession(sess);

		getFacilitiesManagerBl().checkFacilityExists(sess, facility);
		getPerunBl().getGroupsManagerBl().checkGroupExists(sess, group);
		// Authorization
		if (!AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN, facility)) {
			throw new PrivilegeException(sess, "deleteAdmin");
		}

		getFacilitiesManagerBl().removeAdmin(sess, facility, group);

	}

	public List<User> getAdmins(PerunSession perunSession, Facility facility, boolean onlyDirectAdmins) throws InternalErrorException, PrivilegeException, FacilityNotExistsException {
		Utils.checkPerunSession(perunSession);
		getFacilitiesManagerBl().checkFacilityExists(perunSession, facility);

		// Authorization
		if (!AuthzResolver.isAuthorized(perunSession, Role.FACILITYADMIN, facility)) {
			throw new PrivilegeException(perunSession, "getAdmins");
		}

		return getFacilitiesManagerBl().getAdmins(perunSession, facility, onlyDirectAdmins);
	}


	public List<RichUser> getRichAdmins(PerunSession perunSession, Facility facility, List<String> specificAttributes, boolean allUserAttributes, boolean onlyDirectAdmins) throws InternalErrorException, UserNotExistsException, PrivilegeException, FacilityNotExistsException {
		Utils.checkPerunSession(perunSession);
		getFacilitiesManagerBl().checkFacilityExists(perunSession, facility);
		if(!allUserAttributes) Utils.notNull(specificAttributes, "specificAttributes");

		// Authorization
		if (!AuthzResolver.isAuthorized(perunSession, Role.FACILITYADMIN, facility)) {
			throw new PrivilegeException(perunSession, "getRichAdmins");
		}

		return getPerunBl().getUsersManagerBl().filterOnlyAllowedAttributes(perunSession, getFacilitiesManagerBl().getRichAdmins(perunSession, facility, specificAttributes, allUserAttributes, onlyDirectAdmins));
	}

	@Deprecated
	public List<User> getAdmins(PerunSession sess, Facility facility) throws InternalErrorException, FacilityNotExistsException, PrivilegeException {
		Utils.checkPerunSession(sess);

		getFacilitiesManagerBl().checkFacilityExists(sess, facility);
		// Authorization
		if (!AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN, facility)) {
			throw new PrivilegeException(sess, "getAdmins");
		}

		return getFacilitiesManagerBl().getAdmins(sess, facility);
	}

	@Deprecated
	@Override
	public List<User> getDirectAdmins(PerunSession sess, Facility facility) throws InternalErrorException, FacilityNotExistsException, PrivilegeException {
		Utils.checkPerunSession(sess);

		getFacilitiesManagerBl().checkFacilityExists(sess, facility);
		// Authorization
		if (!AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN, facility)) {
			throw new PrivilegeException(sess, "getDirectAdmins");
		}

		return getFacilitiesManagerBl().getDirectAdmins(sess, facility);
	}

	@Override
	public List<Group> getAdminGroups(PerunSession sess, Facility facility) throws InternalErrorException, FacilityNotExistsException, PrivilegeException {
		Utils.checkPerunSession(sess);

		getFacilitiesManagerBl().checkFacilityExists(sess, facility);
		// Authorization
		if (!AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN, facility)) {
			throw new PrivilegeException(sess, "getAdminGroups");
		}

		return getFacilitiesManagerBl().getAdminGroups(sess, facility);
	}

	@Deprecated
	public List<RichUser> getRichAdmins(PerunSession sess, Facility facility) throws InternalErrorException, UserNotExistsException, FacilityNotExistsException, PrivilegeException {
		Utils.checkPerunSession(sess);

		getFacilitiesManagerBl().checkFacilityExists(sess, facility);
		// Authorization
		if (!AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN, facility)) {
			throw new PrivilegeException(sess, "getRichAdmins");
		}

		return getPerunBl().getUsersManagerBl().filterOnlyAllowedAttributes(sess, getFacilitiesManagerBl().getRichAdmins(sess, facility));
	}

	@Deprecated
	public List<RichUser> getRichAdminsWithAttributes(PerunSession sess, Facility facility) throws InternalErrorException, UserNotExistsException, FacilityNotExistsException, PrivilegeException {
		Utils.checkPerunSession(sess);

		getFacilitiesManagerBl().checkFacilityExists(sess, facility);
		// Authorization
		if (!AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN, facility)) {
			throw new PrivilegeException(sess, "getRichAdminsWithAttributes");
		}

		return getPerunBl().getUsersManagerBl().filterOnlyAllowedAttributes(sess, getFacilitiesManagerBl().getRichAdminsWithAttributes(sess, facility));
	}

	@Deprecated
	public List<RichUser> getRichAdminsWithSpecificAttributes(PerunSession perunSession, Facility facility, List<String> specificAttributes) throws InternalErrorException, PrivilegeException, FacilityNotExistsException {
		Utils.checkPerunSession(perunSession);

		getFacilitiesManagerBl().checkFacilityExists(perunSession, facility);
		// Authorization
		if (!AuthzResolver.isAuthorized(perunSession, Role.FACILITYADMIN, facility)) {
			throw new PrivilegeException(perunSession, "getRichAdminsWithSpecificAttributes");
		}

		return getPerunBl().getUsersManagerBl().filterOnlyAllowedAttributes(perunSession, getFacilitiesManagerBl().getRichAdminsWithSpecificAttributes(perunSession, facility, specificAttributes));
	}

	@Deprecated
	public List<RichUser> getDirectRichAdminsWithSpecificAttributes(PerunSession perunSession, Facility facility, List<String> specificAttributes) throws InternalErrorException, PrivilegeException, FacilityNotExistsException {
		Utils.checkPerunSession(perunSession);

		getFacilitiesManagerBl().checkFacilityExists(perunSession, facility);
		// Authorization
		if (!AuthzResolver.isAuthorized(perunSession, Role.FACILITYADMIN, facility)) {
			throw new PrivilegeException(perunSession, "getDirectRichAdminsWithSpecificAttributes");
		}

		return getPerunBl().getUsersManagerBl().filterOnlyAllowedAttributes(perunSession, getFacilitiesManagerBl().getDirectRichAdminsWithSpecificAttributes(perunSession, facility, specificAttributes));
	}

	public List<Facility> getFacilitiesWhereUserIsAdmin(PerunSession sess, User user) throws InternalErrorException, UserNotExistsException, PrivilegeException {
		Utils.checkPerunSession(sess);

		// Authorization
		if(!AuthzResolver.isAuthorized(sess, Role.SELF, user)) {
			throw new PrivilegeException(sess, "getFacilitiesWhereUserIsAdmin");
		}

		getPerunBl().getUsersManagerBl().checkUserExists(sess, user);

		return getFacilitiesManagerBl().getFacilitiesWhereUserIsAdmin(sess, user);
	}

	public void copyManagers(PerunSession sess, Facility sourceFacility, Facility destinationFacility) throws InternalErrorException, PrivilegeException, FacilityNotExistsException {
		Utils.checkPerunSession(sess);

		getFacilitiesManagerBl().checkFacilityExists(sess, sourceFacility);
		getFacilitiesManagerBl().checkFacilityExists(sess, destinationFacility);

		// Authorization - facility admin of the both facilities required
		if (!AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN, sourceFacility)) {
			throw new PrivilegeException(sess, "copyManager");
		}
		if (!AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN, destinationFacility)) {
			throw new PrivilegeException(sess, "copyManager");
		}

		getFacilitiesManagerBl().copyManagers(sess, sourceFacility, destinationFacility);
	}

	public void copyAttributes(PerunSession sess, Facility sourceFacility, Facility destinationFacility) throws InternalErrorException, PrivilegeException, FacilityNotExistsException, WrongAttributeAssignmentException, WrongAttributeValueException, WrongReferenceAttributeValueException {
		Utils.checkPerunSession(sess);

		getFacilitiesManagerBl().checkFacilityExists(sess, sourceFacility);
		getFacilitiesManagerBl().checkFacilityExists(sess, destinationFacility);

		// Authorization - facility admin of the both facilities required
		if (!AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN, sourceFacility)) {
			throw new PrivilegeException(sess, "copyAttributes");
		}
		if (!AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN, destinationFacility)) {
			throw new PrivilegeException(sess, "copyAttributes");
		}

		getFacilitiesManagerBl().copyAttributes(sess, sourceFacility, destinationFacility);
	}


	/**
	 * Sets the facilitiesManagerBl for this instance.
	 *
	 * @param facilitiesManagerBl The facilitiesManagerBl.
	 */
	public void setFacilitiesManagerBl(FacilitiesManagerBl facilitiesManagerBl)
	{
		this.facilitiesManagerBl = facilitiesManagerBl;
	}

	public PerunBl getPerunBl() {
		return this.perunBl;
	}

	public Host addHost(PerunSession sess, Host host, Facility facility) throws InternalErrorException, FacilityNotExistsException, PrivilegeException {
		Utils.checkPerunSession(sess);

		getFacilitiesManagerBl().checkFacilityExists(sess, facility);
		// Authorization
		if (!AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN, facility)) {
			throw new PrivilegeException(sess, "addHost");
		}

		Utils.notNull(host, "hosts");

		List<Facility> facilitiesByHostname = getFacilitiesManagerBl().getFacilitiesByHostName(sess, host.getHostname());
		List<Facility> facilitiesByDestination = getFacilitiesManagerBl().getFacilitiesByDestination(sess, host.getHostname());

		if(facilitiesByHostname.isEmpty() && facilitiesByDestination.isEmpty()) {
			return getFacilitiesManagerBl().addHost(sess, host, facility);
		}
		if(!facilitiesByHostname.isEmpty()) {
			boolean hasRight = false;
			for(Facility f: facilitiesByHostname) {
				if(AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN, f)) {
					hasRight = true;
					break;
				}
			}
			if(hasRight) return getFacilitiesManagerBl().addHost(sess, host, facility);
		}
		if(!facilitiesByDestination.isEmpty()) {
			boolean hasRight = false;
			for(Facility f: facilitiesByDestination) {
				if(AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN, f)) {
					hasRight = true;
					break;
				}
			}
			if(hasRight) return getFacilitiesManagerBl().addHost(sess, host, facility);
		}

		throw new PrivilegeException(sess, "You can't add host " + host + ", because you don't have privileges to use this hostName");
	}

	public void removeHost(PerunSession sess, Host host) throws InternalErrorException, HostNotExistsException, PrivilegeException, HostAlreadyRemovedException {
		Utils.checkPerunSession(sess);

		getFacilitiesManagerBl().checkHostExists(sess, host);
		Facility facility = getFacilitiesManagerBl().getFacilityForHost(sess, host);

		// Authorization
		if (!AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN, facility)) {
			throw new PrivilegeException(sess, "removeHost");
		}

		getFacilitiesManagerBl().removeHost(sess, host);
	}

	public Host getHostById(PerunSession sess, int hostId) throws HostNotExistsException, InternalErrorException, PrivilegeException {
		Utils.checkPerunSession(sess);

		// Authorization
		if (!AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN) &&
				!AuthzResolver.isAuthorized(sess, Role.RPC)) {
			throw new PrivilegeException(sess, "getHostById");
				}

		return getFacilitiesManagerBl().getHostById(sess, hostId);
	}

	public List<Host> getHostsByHostname(PerunSession sess, String hostname) throws InternalErrorException, PrivilegeException {
		Utils.checkPerunSession(sess);
		Utils.notNull(hostname, "hostname");

		if(!AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN)) {
			throw new PrivilegeException(sess, "getHostsByHostname");
		}

		List<Host> hostsByHostname = getFacilitiesManagerBl().getHostsByHostname(sess, hostname);

		//need to remove those hosts, which are not from facilities of this facility admin
		if(!AuthzResolver.hasRole(sess.getPerunPrincipal(), Role.PERUNADMIN) && AuthzResolver.hasRole(sess.getPerunPrincipal(), Role.FACILITYADMIN)) {
			//get all complementary facilities for this perunPrincipal
			List<Facility> authorizedFacilities = new ArrayList<>();
			List<PerunBean> complementaryObjects =  AuthzResolver.getComplementaryObjectsForRole(sess, Role.FACILITYADMIN);
			for(PerunBean pb: complementaryObjects) {
				if(pb instanceof Facility) authorizedFacilities.add((Facility) pb);
			}

			//remove hosts which has not facility from authorized facilities
			Iterator<Host> hostIterator = hostsByHostname.iterator();
			while(hostIterator.hasNext()) {
				Host host = hostIterator.next();
				Facility fac = getPerunBl().getFacilitiesManagerBl().getFacilityForHost(sess, host);
				if(!authorizedFacilities.contains(fac)) hostIterator.remove();
			}
		}

		return hostsByHostname;
	}

	@Override
	public Facility getFacilityForHost(PerunSession sess, Host host) throws InternalErrorException, PrivilegeException, HostNotExistsException {
		Utils.checkPerunSession(sess);

		getFacilitiesManagerBl().checkHostExists(sess, host);

		// Authorization
		if (!AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN)) {
			throw new PrivilegeException(sess, "getFacilityForHost");
		}

		return getFacilitiesManagerBl().getFacilityForHost(sess, host);
	}

	public List<Facility> getFacilitiesByHostName(PerunSession sess, String hostname) throws InternalErrorException, PrivilegeException {
		Utils.checkPerunSession(sess);

		List<Facility> facilities = getFacilitiesManagerBl().getFacilitiesByHostName(sess, hostname);

		if (!facilities.isEmpty()) {
			Iterator<Facility> iterator = facilities.iterator();
			while(iterator.hasNext()) {
				if(!AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN, iterator.next())) iterator.remove();
			}
		}

		return facilities;
	}

	public List<User> getAssignedUsers(PerunSession sess, Facility facility) throws PrivilegeException, InternalErrorException
	{
		Utils.checkPerunSession(sess);

		// Authorization
		if (!AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN)) {
			throw new PrivilegeException(sess, "getAssignedUser");
		}

		return this.getPerunBl().getFacilitiesManagerBl().getAssignedUsers(sess,facility);
	}

	public List<User> getAssignedUsers(PerunSession sess, Facility facility, Service service) throws PrivilegeException, InternalErrorException{
		Utils.checkPerunSession(sess);

		// Authorization
		if (!AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN)) {
			throw new PrivilegeException(sess, "getAssignedUser");
		}

		return this.getPerunBl().getFacilitiesManagerBl().getAssignedUsers(sess,facility,service);
	}

	// FACILITY CONTACTS METHODS

	@Override
	public List<ContactGroup> getFacilityContactGroups(PerunSession sess, Owner owner) throws InternalErrorException, PrivilegeException, OwnerNotExistsException {
		Utils.checkPerunSession(sess);
		perunBl.getOwnersManagerBl().checkOwnerExists(sess, owner);
		List<ContactGroup> contactGroups = this.getFacilitiesManagerBl().getFacilityContactGroups(sess, owner);

		if(contactGroups == null) return new ArrayList<>();

		Iterator<ContactGroup> iter = contactGroups.iterator();
		while(iter.hasNext()) {
			if(!AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN, iter.next().getFacility())) iter.remove();
		}

		return contactGroups;
	}

	@Override
	public List<ContactGroup> getFacilityContactGroups(PerunSession sess, User user) throws InternalErrorException, PrivilegeException, UserNotExistsException {
		Utils.checkPerunSession(sess);
		perunBl.getUsersManagerBl().checkUserExists(sess, user);
		List<ContactGroup> contactGroups = this.getFacilitiesManagerBl().getFacilityContactGroups(sess, user);

		if(contactGroups == null) return new ArrayList<>();

		Iterator<ContactGroup> iter = contactGroups.iterator();
		while(iter.hasNext()) {
			if(!AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN, iter.next().getFacility())) iter.remove();
		}

		return contactGroups;
	}

	@Override
	public List<ContactGroup> getFacilityContactGroups(PerunSession sess, Group group) throws InternalErrorException, PrivilegeException, GroupNotExistsException {
		Utils.checkPerunSession(sess);
		perunBl.getGroupsManagerBl().checkGroupExists(sess, group);
		List<ContactGroup> contactGroups = this.getFacilitiesManagerBl().getFacilityContactGroups(sess, group);

		if(contactGroups == null) return new ArrayList<>();

		Iterator<ContactGroup> iter = contactGroups.iterator();
		while(iter.hasNext()) {
			if(!AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN, iter.next().getFacility())) iter.remove();
		}

		return contactGroups;
	}

	@Override
	public List<ContactGroup> getFacilityContactGroups(PerunSession sess, Facility facility) throws InternalErrorException, FacilityContactNotExistsException, FacilityNotExistsException, PrivilegeException {
		Utils.checkPerunSession(sess);
		perunBl.getFacilitiesManagerBl().checkFacilityExists(sess, facility);

		if(!AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN, facility)) {
			throw new PrivilegeException(sess, "getFacilityContactGroups");
		}

		return this.getFacilitiesManagerBl().getFacilityContactGroups(sess, facility);
	}

	@Override
	public ContactGroup getFacilityContactGroup(PerunSession sess, Facility facility, String name) throws InternalErrorException, FacilityContactNotExistsException, PrivilegeException, FacilityNotExistsException {
		Utils.checkPerunSession(sess);
		Utils.notNull(name, "name");
		this.getFacilitiesManagerBl().checkFacilityExists(sess, facility);

		if(!AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN, facility)) {
			throw new PrivilegeException(sess, "getFacilityContactGroup");
		}

		return this.getFacilitiesManagerBl().getFacilityContactGroup(sess, facility, name);
	}

	@Override
	public List<String> getAllContactGroupNames(PerunSession sess) throws InternalErrorException {
		Utils.checkPerunSession(sess);
		return this.getFacilitiesManagerBl().getAllContactGroupNames(sess);
	}

	@Override
	public void addFacilityContacts(PerunSession sess, List<ContactGroup> contactGroupsToAdd) throws InternalErrorException, PrivilegeException, FacilityNotExistsException, UserNotExistsException, OwnerNotExistsException, GroupNotExistsException {
		Utils.checkPerunSession(sess);
		this.checkFacilityContactsEntitiesExist(sess, contactGroupsToAdd);

		Iterator<ContactGroup> iter = contactGroupsToAdd.iterator();
		while(iter.hasNext()) {
			ContactGroup cg = iter.next();
			if(!AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN, cg.getFacility())) {
				iter.remove();
				continue;
			}
 		}

		if(!contactGroupsToAdd.isEmpty()) {
			this.facilitiesManagerBl.addFacilityContacts(sess, contactGroupsToAdd);
		}
	}

	@Override
	public void addFacilityContact(PerunSession sess, ContactGroup contactGroupToAdd) throws InternalErrorException, PrivilegeException, FacilityNotExistsException, UserNotExistsException, OwnerNotExistsException, GroupNotExistsException {
		Utils.checkPerunSession(sess);
		this.checkFacilityContactEntitiesExists(sess, contactGroupToAdd);

		if(!AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN, contactGroupToAdd.getFacility())) {
			throw new PrivilegeException(sess, "addFacilityContact");
		}

		this.getFacilitiesManagerBl().addFacilityContact(sess, contactGroupToAdd);
	}

	@Override
	public void removeFacilityContacts(PerunSession sess, List<ContactGroup> contactGroupsToRemove) throws InternalErrorException, PrivilegeException, FacilityNotExistsException, UserNotExistsException, OwnerNotExistsException, GroupNotExistsException {
		Utils.checkPerunSession(sess);
		this.checkFacilityContactsEntitiesExist(sess, contactGroupsToRemove);

		Iterator<ContactGroup> iter = contactGroupsToRemove.iterator();
		while(iter.hasNext()) {
			ContactGroup cg = iter.next();

			if(!AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN, cg.getFacility())) {
				throw new PrivilegeException(sess, "removeFacilityContacts");
			}

 		}

		this.getFacilitiesManagerBl().removeFacilityContacts(sess, contactGroupsToRemove);
	}

	@Override
	public void removeFacilityContact(PerunSession sess, ContactGroup contactGroupToRemove) throws InternalErrorException, PrivilegeException, FacilityNotExistsException, UserNotExistsException, OwnerNotExistsException, GroupNotExistsException {
		Utils.checkPerunSession(sess);
		this.checkFacilityContactEntitiesExists(sess, contactGroupToRemove);

		if(!AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN, contactGroupToRemove.getFacility())) {
			throw new PrivilegeException(sess, "contactGroupToRemove");
		}

		this.getFacilitiesManagerBl().removeFacilityContact(sess, contactGroupToRemove);
	}

	@Override
	public List<SecurityTeam> getAssignedSecurityTeams(PerunSession sess, Facility facility) throws InternalErrorException, PrivilegeException, FacilityNotExistsException {
		Utils.checkPerunSession(sess);
		getFacilitiesManagerBl().checkFacilityExists(sess, facility);

		if(!AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN, facility)) {
			throw new PrivilegeException(sess, "getAssignedSecurityTeams");
		}

		return this.getFacilitiesManagerBl().getAssignedSecurityTeams(sess, facility);
	}

	@Override
	public void assignSecurityTeam(PerunSession sess, Facility facility, SecurityTeam securityTeam) throws InternalErrorException, PrivilegeException, SecurityTeamNotExistsException, FacilityNotExistsException, SecurityTeamAlreadyAssignedException {
		Utils.checkPerunSession(sess);
		getPerunBl().getSecurityTeamsManagerBl().checkSecurityTeamExists(sess, securityTeam);
		getFacilitiesManagerBl().checkFacilityExists(sess, facility);
		getFacilitiesManagerBl().checkSecurityTeamNotAssigned(sess, facility, securityTeam);

		if(!AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN, facility)) {
			throw new PrivilegeException(sess, "assignSecurityTeam");
		}

		this.getFacilitiesManagerBl().assignSecurityTeam(sess, facility, securityTeam);
	}

	@Override
	public void removeSecurityTeam(PerunSession sess, Facility facility, SecurityTeam securityTeam) throws InternalErrorException, PrivilegeException, FacilityNotExistsException, SecurityTeamNotExistsException, SecurityTeamNotAssignedException {
		Utils.checkPerunSession(sess);
		getPerunBl().getSecurityTeamsManagerBl().checkSecurityTeamExists(sess, securityTeam);
		getFacilitiesManagerBl().checkFacilityExists(sess, facility);
		getFacilitiesManagerBl().checkSecurityTeamAssigned(sess, facility, securityTeam);

		if(!AuthzResolver.isAuthorized(sess, Role.FACILITYADMIN, facility)) {
			throw new PrivilegeException(sess, "removeSecurityTeam");
		}

		this.getFacilitiesManagerBl().removeSecurityTeam(sess, facility, securityTeam);
	}

	/**
	 * Check existence of every entity in contactGroup
	 *
	 * @param sess
	 * @param contactGroup
	 * @throws FacilityNotExistsException
	 * @throws UserNotExistsException
	 * @throws OwnerNotExistsException
	 * @throws GroupNotExistsException
	 * @throws InternalErrorException
	 */
	private void checkFacilityContactEntitiesExists(PerunSession sess, ContactGroup contactGroup) throws FacilityNotExistsException, UserNotExistsException, OwnerNotExistsException, GroupNotExistsException, InternalErrorException {
		Utils.notNull(contactGroup, "contactGroup");
		Utils.notNull(contactGroup.getFacility(), "facility");
		Utils.notNull(contactGroup.getName(), "name");

		this.getFacilitiesManagerBl().checkFacilityExists(sess, contactGroup.getFacility());

		if(contactGroup.getUsers() != null) {
			for(RichUser user: contactGroup.getUsers()) {
				getPerunBl().getUsersManagerBl().checkUserExists(sess, user);
			}
		}

		if(contactGroup.getGroups() != null) {
			for(Group group: contactGroup.getGroups()) {
				getPerunBl().getGroupsManagerBl().checkGroupExists(sess, group);
			}
		}

		if(contactGroup.getOwners() != null) {
			for(Owner owner: contactGroup.getOwners()) {
				getPerunBl().getOwnersManagerBl().checkOwnerExists(sess, owner);
			}
		}
	}

	/**
	 * Check existence of every entity in list of contactGroups
	 *
	 * @param sess
	 * @param contactGroups
	 * @throws FacilityNotExistsException
	 * @throws UserNotExistsException
	 * @throws OwnerNotExistsException
	 * @throws GroupNotExistsException
	 * @throws InternalErrorException
	 */
	private void checkFacilityContactsEntitiesExist(PerunSession sess, List<ContactGroup> contactGroups) throws FacilityNotExistsException, UserNotExistsException, OwnerNotExistsException, GroupNotExistsException, InternalErrorException {
		Utils.notNull(contactGroups, "contactGroups");

		for(ContactGroup contactGroup: contactGroups) {
			this.checkFacilityContactEntitiesExists(sess, contactGroup);
		}
	}
}
