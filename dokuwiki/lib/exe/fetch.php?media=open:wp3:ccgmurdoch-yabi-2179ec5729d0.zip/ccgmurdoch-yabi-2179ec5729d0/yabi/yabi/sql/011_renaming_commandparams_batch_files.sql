ALTER TABLE yabiengine_job RENAME COLUMN commandparams TO batch_files;
