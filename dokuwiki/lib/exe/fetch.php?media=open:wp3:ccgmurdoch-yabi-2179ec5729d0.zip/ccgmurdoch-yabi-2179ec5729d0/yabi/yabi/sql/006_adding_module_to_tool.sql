BEGIN;
ALTER TABLE yabmin_tool ADD module text;
COMMIT;
