ALTER TABLE yabiengine_workflow ADD stageout varchar(1000);





