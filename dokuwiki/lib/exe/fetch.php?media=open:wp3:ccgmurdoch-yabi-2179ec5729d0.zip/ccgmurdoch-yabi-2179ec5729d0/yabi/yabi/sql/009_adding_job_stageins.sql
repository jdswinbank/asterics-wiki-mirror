BEGIN;
ALTER TABLE yabiengine_job ADD job_stageins text;
COMMIT;
