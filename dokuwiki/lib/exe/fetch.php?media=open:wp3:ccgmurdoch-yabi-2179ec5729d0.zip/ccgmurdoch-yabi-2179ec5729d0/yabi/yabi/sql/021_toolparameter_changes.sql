ALTER TABLE yabi_toolparameter ALTER COLUMN switch SET NOT NULL;
ALTER TABLE yabi_toolparameter ALTER COLUMN switch_use_id SET NOT NULL;
