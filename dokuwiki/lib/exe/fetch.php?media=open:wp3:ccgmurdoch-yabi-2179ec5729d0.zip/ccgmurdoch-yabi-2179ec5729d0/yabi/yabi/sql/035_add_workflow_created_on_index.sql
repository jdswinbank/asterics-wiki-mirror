BEGIN;
CREATE INDEX "yabiengine_workflow_created_on" ON "yabiengine_workflow" ("created_on");
COMMIT;
