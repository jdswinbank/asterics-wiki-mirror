ALTER TABLE yabmin_backend ALTER COLUMN "hostname" SET NOT NULL;
ALTER TABLE yabmin_backend ALTER COLUMN "path" SET NOT NULL;