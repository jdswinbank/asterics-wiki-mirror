BEGIN;

ALTER TABLE yabiengine_task ADD "remote_id" varchar(256);


COMMIT;