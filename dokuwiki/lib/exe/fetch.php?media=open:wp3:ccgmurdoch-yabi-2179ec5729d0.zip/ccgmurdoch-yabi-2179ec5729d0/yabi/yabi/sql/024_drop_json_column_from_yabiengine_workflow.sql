BEGIN;
ALTER TABLE yabiengine_workflow DROP COLUMN json;
COMMIT;
