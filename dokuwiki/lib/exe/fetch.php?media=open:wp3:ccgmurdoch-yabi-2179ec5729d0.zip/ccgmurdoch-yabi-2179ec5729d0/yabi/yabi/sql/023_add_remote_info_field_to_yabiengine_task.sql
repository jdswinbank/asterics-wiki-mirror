BEGIN;

ALTER TABLE yabiengine_task ADD "remote_info" varchar(2048);


COMMIT;