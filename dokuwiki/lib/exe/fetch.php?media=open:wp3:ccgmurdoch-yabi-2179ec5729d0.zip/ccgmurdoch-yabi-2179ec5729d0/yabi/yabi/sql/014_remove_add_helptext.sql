BEGIN;
ALTER TABLE yabmin_toolparameter ADD helptext text;
COMMIT;
