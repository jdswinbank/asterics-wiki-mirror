BEGIN;
ALTER TABLE yabmin_parameterswitchuse ALTER formatstring TYPE varchar(256);
COMMIT;
