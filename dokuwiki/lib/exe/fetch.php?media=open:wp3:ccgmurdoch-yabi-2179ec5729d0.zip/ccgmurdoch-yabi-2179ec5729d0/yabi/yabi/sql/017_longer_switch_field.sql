BEGIN;
ALTER TABLE yabmin_toolparameter ALTER switch TYPE varchar(64);
COMMIT;
