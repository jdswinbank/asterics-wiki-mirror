ALTER TABLE yabiengine_workflow DROP COLUMN yabistore_id;
