DROP TABLE celery_taskmeta;
DROP SEQUENCE celery_taskmeta_id_seq CASCADE;
DROP TABLE celery_tasksetmeta;
DROP SEQUENCE celery_tasksetmeta_id_seq CASCADE;
