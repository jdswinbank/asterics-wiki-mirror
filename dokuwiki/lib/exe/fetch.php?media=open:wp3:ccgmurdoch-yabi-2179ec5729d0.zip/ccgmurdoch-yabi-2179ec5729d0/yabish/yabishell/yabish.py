# Yabi - a sophisticated online research environment for Grid, High Performance and Cloud computing.
# Copyright (C) 2015  Centre for Comparative Genomics, Murdoch University.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as
# published by the Free Software Foundation, either version 3 of the
# License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

from __future__ import print_function
from argparse import ArgumentParser
from collections import namedtuple
import json
import os
import sys
import uuid
import Cookie

from urllib import quote
from yaphc import Http, UnauthorizedError, PostRequest, GetRequest
from yabishell import errors
from yabishell import actions
from yabishell.utils import human_readable_size
from six.moves import filter
from six.moves import map

YABI_DEFAULT_URL = os.environ.get('YABISH_YABI_URL', 'https://ccgapps.com.au/yabi/')


def main():
    debug = False
    yabi = None
    stagein = None
    exit_code = 0
    try:
        argparser = ArgumentParser(add_help=False)
        argparser.add_argument("--yabi-debug", action='store_true', help="Run in debug mode")
        argparser.add_argument("--yabi-bg", action='store_true', help="Run in background")
        argparser.add_argument("--yabi-url", help="The URL of the YABI server",
                               default=YABI_DEFAULT_URL)
        argparser.add_argument("--backend", metavar="BACKEND", default=None,
                               help="Sets the execution backend.")
        options, args = argparser.parse_known_args()

        args = CommandLineArguments(args)

        if args.no_arguments or args.first_argument in ('-h', '--help'):

            print_help()
            return

        if args.first_argument in ('-v', '--version'):
            print_version()
            return

        debug = options.yabi_debug
        yabi = Yabi(url=options.yabi_url, backend=options.backend,
                    bg=options.yabi_bg, debug=options.yabi_debug)
        action = yabi.choose_action(args.first_argument)
        if action.stagein_required():
            stagein = StageIn(yabi, args)
            files_uris = stagein.do()
            if files_uris:
                args.substitute_file_urls(files_uris)
        action.process(args.rest_of_arguments)
        if stagein:
            stagein.delete_stageindir()

    except Exception as e:
        print_error(e, debug)
        exit_code = 1
    finally:
        if yabi is not None:
            yabi.session_finished()

    exit(exit_code)


def print_help():
    help_file = os.path.join(os.path.dirname(__file__), 'help/main')
    with open(help_file) as f:
        print(f.read())


class StageIn(object):
    def __init__(self, yabi, args):
        self.yabi = yabi
        self.args = args
        self.stageindir = None
        self.files = None

    @property
    def debug(self):
        return self.yabi.debug

    def do(self):
        if not self.args.local_files:
            return
        self.files = self.files_to_stagein()
        if not self.files:
            return

        files_to_uris = {}
        alldirs, allfiles, total_size = self.collect_files()
        stagein_dir, dir_uris = self.create_stagein_dir(alldirs)
        print("Staging in %s in %i directories and %i files." % (
            human_readable_size(total_size), len(alldirs), len(allfiles)))
        files_to_uris.update(dir_uris)
        for f in allfiles:
            rel_path, fname = os.path.split(f.relpath)
            file_uri = self.stagein_file(f, stagein_dir + rel_path)
            files_to_uris[f.relpath.encode("utf-8")] = file_uri
        print("Staging in finished.")
        return files_to_uris

    def collect_files(self):
        allfiles = []
        alldirs = []
        total_size = 0
        RelativeFile = namedtuple('RelativeFile', 'relpath fullpath')
        for f in self.files:
            if os.path.isfile(f):
                allfiles.append(RelativeFile(os.path.basename(f), f))
                total_size += os.path.getsize(f)
            if os.path.isdir(f):
                path, dirname = os.path.split(f)
                alldirs.append(RelativeFile(dirname, f))
                for root, dirs, files in os.walk(f):
                    for adir in dirs:
                        dpath = os.path.join(root, adir)
                        rel_dir = dpath[len(f) - 1:]
                        alldirs.append(RelativeFile(rel_dir, dpath))
                    for afile in files:
                        fpath = os.path.join(root, afile)
                        rpath = fpath[len(f) - 1:]
                        allfiles.append(RelativeFile(rpath, fpath))
                        total_size += os.path.getsize(fpath)
        return alldirs, allfiles, total_size

    def files_to_stagein(self):
        uri = 'ws/yabish/is_stagein_required'
        params = {'name': self.args.first_argument}
        for i, a in enumerate(self.args.rest_of_arguments):
            params['arg%i' % i] = a
        resp, json_response = self.yabi.post(uri, params)
        response = json.loads(json_response)
        if not response.get('stagein_required'):
            return []
        local_files = self.args.local_files
        return filter(lambda f: f in local_files, response['files'])

    def create_stagein_dir(self, dir_structure):
        uri = 'ws/yabish/createstageindir'
        params = {'uuid': uuid.uuid1()}
        for i, d in enumerate(dir_structure):
            params['dir_%i' % i] = d.relpath
        resp, json_response = self.yabi.post(uri, params)
        response = json.loads(json_response)
        if not response.get('success'):
            raise errors.RemoteError(
                "Couldn't create stagein directory on the server (%s)" % response.get('msg'))
        stageindir_uri = response['uri']
        dir_uri_mapping = {}
        for d in dir_structure:
            dir_uri = stageindir_uri + d.relpath
            if not dir_uri.endswith('/'):
                dir_uri += '/'
            dir_uri_mapping[d.relpath] = dir_uri
        return stageindir_uri, dir_uri_mapping

    def stagein_file(self, f, stagein_dir):
        uri = 'ws/fs/put?uri=%s' % quote(stagein_dir)
        fname = os.path.basename(f.relpath)
        fname = quote(fname.encode('utf-8'))
        finfo = (fname, fname, f.fullpath)
        params = {}
        print('  Staging in file: %s (%s).' % (
            f.relpath, human_readable_size(os.path.getsize(f.fullpath))))
        resp, json_response = self.yabi.post(uri, params, files=[finfo])
        assert resp.status == 200
        return os.path.join(stagein_dir, fname)

    def delete_stageindir(self):
        if self.stageindir:
            self.yabi.delete_dir(self.stageindir)


class Yabi(object):
    def __init__(self, url, backend=None, bg=False, debug=False):
        self._http = None
        self.yabi_url = url
        self.workdir = os.path.expanduser('~/.yabish')
        self.cachedir = os.path.join(self.workdir, 'cache')
        self.csrftokenfile = os.path.join(self.workdir, 'csrf_token')
        self.cookiesfile = os.path.join(self.workdir, 'cookies.txt')
        self.username = None
        self.backend = backend
        self.run_in_background = bg
        self.debug = debug
        if self.debug:
            import httplib2
            httplib2.debuglevel = 1

    @property
    def http(self):
        if self._http is None:
            self._http = Http(workdir=self.workdir, base_url=self.yabi_url)
        return self._http

    @property
    def csrf_token(self):
        token = None
        if os.path.exists(self.csrftokenfile):
            with open(self.csrftokenfile) as f:
                token = f.read().strip()
        if not token:
            token = self.retrieve_csrf_token()
            if token is not None:
                with open(self.csrftokenfile, "w") as f:
                    f.write(token)
        return token

    def retrieve_csrf_token(self):
        url = self.yabi_url.rstrip('/') + '/login'
        resp, contents = self.http.make_request(self._create_request('GET', url))
        cookies = Cookie.SimpleCookie()
        cookies.load(resp.get('set-cookie', ''))

        csrf_cookie = None
        for name, value in cookies.items():
            # We do not know the exact name of the CSRF cookie on the
            # client-side but we know it starts with 'csrf_yabi_'
            if name.startswith('csrf_yabi'):
                csrf_cookie = value
                break
        csrf_token = None
        if csrf_cookie is not None:
            csrf_token = csrf_cookie.value
        return csrf_token

    def reset_csrf_token(self):
        os.unlink(self.csrftokenfile)

    def delete_dir(self, stageindir):
        rmdir = actions.Rm(self)
        rmdir.process([stageindir])

    def login(self):
        import getpass
        system_user = getpass.getuser()
        username = raw_input('Username (%s): ' % system_user)
        if '' == username.strip():
            username = system_user
        password = getpass.getpass()
        login_action = actions.Login(self)
        return login_action.process([username, password])

    def _create_request(self, method, url, params=None, files=None):
        if method not in ('GET', 'POST'):
            raise ValueError("Method should be GET or POST")
        if params is None:
            params = {}
        # Pretend we're making AJAX calls
        headers = {'HTTP_X_REQUESTED_WITH': 'XMLHttpRequest'}

        if method == 'POST':
            if self.csrf_token is not None:
                headers['Referer'] = self.yabi_url
                headers['X-CSRFToken'] = self.csrf_token

        if method == 'GET':
            request = GetRequest(url, params, headers=headers)
        elif method == 'POST':
            request = PostRequest(url, params, files=files, headers=headers)

        return request

    def request(self, method, url, params=None, files=None):
        try:
            request = self._create_request(method, url, params, files)
            if self.debug:
                print('=' * 5 + 'Making HTTP request')
            resp, contents = self.http.make_request(request)
            if self.debug:
                print(resp, contents)
                print('=' * 5 + 'End of HTTP request')
        except UnauthorizedError:
            if not self.login():
                raise Exception("Invalid username/password")
            resp, contents = self.http.make_request(request)
        if int(resp.status) == 403:
            # CSRF token error. Reset the token and try again.
            self.reset_csrf_token()
            request = self._create_request(method, url, params, files)
            resp, contents = self.http.make_request(request)
        if int(resp.status) >= 400:
            raise errors.CommunicationError(int(resp.status), url, contents)
        return resp, contents

    def get(self, url, params=None):
        return self.request('GET', url, params)

    def post(self, url, params=None, files=None):
        return self.request('POST', url, params=params, files=files)

    def choose_action(self, action_name):
        class_name = action_name.capitalize()
        try:
            cls = getattr(sys.modules['yabishell.actions'], class_name)
        except AttributeError:
            if self.run_in_background:
                cls = actions.BackgroundRemoteAction
            else:
                cls = actions.ForegroundRemoteAction
        return cls(self, name=action_name)

    def session_finished(self):
        if self._http:
            self._http.finish_session()


def print_version():
    from .version import __version__
    print('yabish %s' % __version__)


def print_error(error, debug=False):
    print('An error occured: \n\t%s' % error, file=sys.stderr)
    if debug:
        print('-' * 5 + ' DEBUG ' + '-' * 5, file=sys.stderr)
        import traceback
        traceback.print_exc()


class CommandLineArguments(object):
    def __init__(self, args):
        self.args = args

    @property
    def no_arguments(self):
        return len(self.args) == 0

    @property
    def first_argument(self):
        return self.args[0]

    @property
    def rest_of_arguments(self):
        return [] if len(self.args) <= 1 else self.args[1:]

    @property
    def all_arguments(self):
        return self.args

    @property
    def local_files(self):
        # if argument has "=" return right side else return argument
        args_and_values = list(map(lambda a: a.split('=', 1)[1] if '=' in a else a, self.args))
        args = map(lambda x: x.decode("utf-8"), args_and_values)
        return [arg for arg in args if os.path.isfile(arg) or os.path.isdir(arg)]

    def substitute_file_urls(self, urls):
        def file_to_url(arg):
            new_arg = arg
            if os.path.isfile(arg) or os.path.isdir(arg):
                new_arg = urls.get(os.path.basename(arg), arg)
            else:
                # also try right-side of = to handle combined with equals with file values
                if '=' in arg:
                    name, value = arg.split('=', 1)
                    if os.path.isfile(value) or os.path.isdir(value):
                        new_arg = "%s=%s" % (name, urls.get(os.path.basename(value), value))
            return new_arg
        self.args = list(map(file_to_url, self.args))
