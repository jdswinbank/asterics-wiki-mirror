.. Yabi documentation master file, created by
   sphinx-quickstart on Thu Apr  5 11:15:22 2012.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Yabi Documentation
================================

.. toctree::
    :maxdepth: 3

    about
    installation/index
    logging
    testing
    authentication
    addingusers
    backends
    credentials
    backendcredentials
    dynamicbackends
    submissiontemplates
    tools
    tool_import_export
    toolsets_and_toolgroups
    faq

