.. highlight:: console

.. _yabish:

Setting up Yabish
-----------------

Yabish is the command line client that you might want to install on machines used by end users of Yabi.

Make sure you've added the CCG repo as described in :ref:`extra-repos`.
Then install the ``yabi-shell`` package::

 # yum install yabi-shell

This installs the CLI for Yabi in ``/usr/bin/yabish``.
