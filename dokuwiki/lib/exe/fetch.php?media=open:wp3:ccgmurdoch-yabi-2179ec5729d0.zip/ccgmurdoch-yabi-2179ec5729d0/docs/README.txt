Building Yabi Documentation
---------------------------

The Yabi Documentation can be built using Sphinx. In the same directory as this document run these commands:

sh ../bootstrap.sh
source virt_docs/bin/activate
make html

Your docs are now in the _build/html directory.

