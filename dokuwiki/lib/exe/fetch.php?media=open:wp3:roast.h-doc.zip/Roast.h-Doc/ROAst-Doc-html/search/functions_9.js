var searchData=
[
  ['setdatacard',['SetDataCard',['../classROAst_1_1GENHENGenerator.html#a6a20215f1fd4a3f52f0f69fc4cf5b0b3',1,'ROAst::GENHENGenerator']]],
  ['setregcentre',['SetRegCentre',['../classROAst_1_1Region.html#aa2390f7eb64f8eb1edbc390002826d15',1,'ROAst::Region']]],
  ['setregheight',['SetRegHeight',['../classROAst_1_1Box.html#a2d0ed69c16dcadb73152493dfa427a49',1,'ROAst::Box']]],
  ['setregr',['SetRegR',['../classROAst_1_1Circle.html#aab97e39595bb104b48e9f4500b562b62',1,'ROAst::Circle']]],
  ['setregsecondpoint',['SetRegSecondPoint',['../classROAst_1_1Line.html#abe64283b5526f385bb7ae51675546072',1,'ROAst::Line']]],
  ['setregvertex',['SetRegVertex',['../classROAst_1_1Box.html#a6894e8bc7a4610e92c77dfc34ce9458d',1,'ROAst::Box']]],
  ['setregwidth',['SetRegWidth',['../classROAst_1_1Box.html#a37e4d609127979db58ac9565e60431f4',1,'ROAst::Box']]],
  ['setrmaxextent',['SetRMaxExtent',['../classROAst_1_1Ellipse.html#a41981a84efc379733c06ab8f68d42367',1,'ROAst::Ellipse::SetRMaxExtent(EqAstCoord rmaxextent)'],['../classROAst_1_1Ellipse.html#a26748adeb3a952c5c4bec8d6c59325a0',1,'ROAst::Ellipse::SetRMaxExtent(double RMinExtent)']]],
  ['setsavefilename',['SetSaveFileName',['../classROAst_1_1CosmicParticleGenerator.html#ad2195dd1a94b1a0d83790abf03e1b376',1,'ROAst::CosmicParticleGenerator']]],
  ['setsysconfig',['SetSysConfig',['../classROAst_1_1GENHENGenerator.html#a9ca5cc72cc9b0a36a8d21542240823a9',1,'ROAst::GENHENGenerator']]]
];
