var searchData=
[
  ['astroobject',['AstroObject',['../structROAst_1_1AstroObject.html',1,'ROAst']]]
];
