var searchData=
[
  ['nrabsorblengths',['NrAbsorbLengths',['../structROAst_1_1GENHENDatacard.html#a041f1db7f34b85e1d52a688aafd43d0b',1,'ROAst::GENHENDatacard']]],
  ['nrenergybin',['NrEnergyBin',['../structROAst_1_1GENHENDatacard.html#a2badef8f7c31befa482eae6e047e6252',1,'ROAst::GENHENDatacard']]],
  ['nrevents',['NrEvents',['../structROAst_1_1GENHENDatacard.html#aa7f7e08c6af5e1bbd5797e1cd04ec894',1,'ROAst::GENHENDatacard']]]
];
