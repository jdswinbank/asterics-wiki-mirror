var searchData=
[
  ['objecttype',['ObjectType',['../structROAst_1_1AstroObject.html#a4225254809f33471c4fd2f49aa31cd62',1,'ROAst::AstroObject']]]
];
