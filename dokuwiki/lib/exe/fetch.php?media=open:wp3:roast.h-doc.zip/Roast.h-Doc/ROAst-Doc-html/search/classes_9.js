var searchData=
[
  ['spectralmagnitude',['SpectralMagnitude',['../structROAst_1_1SpectralMagnitude.html',1,'ROAst']]]
];
