var searchData=
[
  ['astlong',['AstLong',['../structROAst_1_1GalactiCoord.html#a4c144cee090460439c2a097bc2b58a36',1,'ROAst::GalactiCoord']]]
];
