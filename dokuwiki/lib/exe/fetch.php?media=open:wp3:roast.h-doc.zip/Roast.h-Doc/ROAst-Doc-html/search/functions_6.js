var searchData=
[
  ['neutrinogenerator',['NeutrinoGenerator',['../classROAst_1_1NeutrinoGenerator.html#a113205429d2f2848e2f63748c67b9ccf',1,'ROAst::NeutrinoGenerator']]]
];
