var searchData=
[
  ['fromfile',['FromFile',['../classROAst_1_1GENHENGenerator.html#a4c83c4e2f4e77459fbe28b64cef33f7e',1,'ROAst::GENHENGenerator::FromFile()'],['../classROAst_1_1CosmicParticleGenerator.html#ae27faecedea24455e15c774694ca82ef',1,'ROAst::CosmicParticleGenerator::FromFile()']]]
];
