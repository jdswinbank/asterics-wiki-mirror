#ifndef _PLISA_H_
#define _PLISA_H_

namespace pLISA
{
	namespace Devices
	{
		typedef unsigned DeviceTypeId;

		DeviceTypeId const Host = 0;
		DeviceTypeId const GPU = 1;
		DeviceTypeId const MIC = 2;	

		typedef unsigned long long InternalEncodingFlag;

		namespace InternalEncodingFlags
		{

			/* Reserved to pLISA-provided algorithms. All user code should avoid this flag. */
			const InternalEncodingFlag pLISAReserved = (1ull << 63);
			const InternalEncodingFlag InHostMemory = 1;
			const InternalEncodingFlag InGPUMemory = 2;
		
			/* All user code use this flag. */
			const InternalEncodingFlag Custom = 0;
		}
		
		typedef void *DeviceMemoryBlock;
		
		class DeviceMemoryAccessor
		{
		public:
			virtual InternalEncodingFlag InternalEncoding() = 0;
			virtual DeviceMemoryBlock DirectAccess(unsigned blockid) = 0;
			virtual DeviceTypeId Container() = 0;
		};
	}

	typedef unsigned FeatureSetId;

	class FeatureSet
	{
	public:
		virtual FeatureSetId GetFeatureSetId() = 0; 
	};

	namespace Hits
	{
		namespace Features
		{
			FeatureSetId const Null = 0x0;
			FeatureSetId const Identification = 0x1;
			FeatureSetId const CustomIdentification = 0x2;
			FeatureSetId const Basic = 0x30;
			FeatureSetId const Direction = 0x40;
			FeatureSetId const Weight = 0x50;
			FeatureSetId const MonteCarlo = 0x10;
			FeatureSetId const CustomMonteCarlo = 0x20;
			FeatureSetId const Background = 0x100;
			FeatureSetId const CustomBackground = 0x200;
			FeatureSetId const Trigger = 0x1000;
			FeatureSetId const CustomTrigger = 0x2000;
			FeatureSetId const Reconstruction = 0x10000;
			FeatureSetId const CustomReconstruction = 0x20000;
		}

		class IdentificationSet : public FeatureSet
		{
		public:
			virtual FeatureSetId GetFeatureSetId() { return Features::Identification; }
			virtual unsigned int Id() = 0;
		};

		/* The custom identification feature set must be provided by the experiment code. */

		class BasicSet : public FeatureSet
		{
		public:
			virtual FeatureSetId GetFeatureSetId() { return Features::Basic; }
			virtual double X() = 0;
			virtual double Y() = 0;
			virtual double Z() = 0;
			virtual double T() = 0;
		};

		class DirectionSet : public FeatureSet
		{
		public:
			virtual FeatureSetId GetFeatureSetId() { return Features::Direction; }
			virtual double DirX() = 0;
			virtual double DirY() = 0;
			virtual double DirZ() = 0;
		};

		class WeightSet : public FeatureSet
		{
		public:
			virtual FeatureSetId GetFeatureSetId() { return Features::Weight; }
			virtual double Weight() = 0;
		};

		class MonteCarloSet : public FeatureSet
		{
		public:
			virtual FeatureSetId GetFeatureSetId() { return Features::MonteCarlo; }
			virtual bool IsSimulated() = 0;
		};

		/* The custom montecarlo feature set must be provided by the experiment code. */


		class BackgroundSet : public FeatureSet
		{
		public:
			virtual FeatureSetId GetFeatureSetId() { return Features::Background; }
			virtual bool IsBackground() = 0;
		};

		/* The custom background feature set must be provided by the experiment code. */

		class TriggerSet : public FeatureSet
		{
		public:
			virtual FeatureSetId GetFeatureSetId() { return Features::Trigger; }
			virtual bool IsTriggered() = 0;
		};

		/* The custom trigger feature set must be provided by the experiment code. */

		class ReconstructionSet : public FeatureSet
		{
		public:
			virtual FeatureSetId GetFeatureSetId() { return Features::Reconstruction; }
			virtual bool IsInReconstruction() = 0;
		};

		/* The custom reconstruction feature set must be provided by the experiment code. */

		class Hit
		{
		public:
			virtual FeatureSetId FeatureSets() = 0;
			virtual bool HasFeatureSet(FeatureSetId mask) = 0;
			/* Exceptions are thrown if attempting to get unsupported feature sets */
			virtual IdentificationSet &Id() = 0;
			virtual BasicSet &Basic() = 0;
			virtual DirectionSet &Direction() = 0;
			virtual WeightSet &Weight() = 0;
			virtual TriggerSet &Trigger() = 0;
			virtual FeatureSet &CustomTrigger() = 0;
			virtual BackgroundSet &Background() = 0;
			virtual ReconstructionSet &Reconstruction() = 0;
		};

		class EventHitSet : public Devices::DeviceMemoryAccessor
		{
		public:
			virtual double UnixTime() = 0;
			virtual unsigned Count() = 0;
			virtual Hit &operator()(unsigned i) = 0;
		};
	}

	namespace Events
	{
		typedef long long PDGId;

		namespace Features
		{
			FeatureSetId const Null = 0x0;
			FeatureSetId const Hits = 0x1;
			FeatureSetId const Track = 0x10;
			FeatureSetId const TrackErrors = 0x20;
			FeatureSetId const Shower = 0x40;
			FeatureSetId const ShowerErrors = 0x80;
			FeatureSetId const ParticleIdentification = 0x100;
			FeatureSetId const Energy = 0x1000;
			FeatureSetId const EnergyErrors = 0x2000;
			FeatureSetId const Momentum = 0x10000;
			FeatureSetId const MomentumErrors = 0x20000;
		}

		class TrackSet : public FeatureSet
		{
		public:
			virtual FeatureSetId GetFeatureSetId() { return Features::Track; }
			virtual double X1() = 0;
			virtual double Y1() = 0;
			virtual double Z1() = 0;
			virtual double X2() = 0;
			virtual double Y2() = 0;
			virtual double Z2() = 0;
			virtual double DirX() = 0;
			virtual double DirY() = 0;
			virtual double DirZ() = 0;
		};

		/* Track fitting errors depend on the algorithm. */

		class ShowerSet : public FeatureSet
		{
		public:
			virtual FeatureSetId GetFeatureSetId() { return Features::Shower; }
			virtual double X() = 0;
			virtual double Y() = 0;
			virtual double Z() = 0;
			virtual double DirX() = 0;
			virtual double DirY() = 0;
			virtual double DirZ() = 0;
			virtual double Radius() = 0;
		};

		/* Shower fitting errors depend on the algorithm. */

		class ParticleIdentificationSet : public FeatureSet
		{
		public:
			virtual FeatureSetId GetFeatureSetId() { return Features::ParticleIdentification; }
			virtual PDGId &Particle() = 0;
		};

		class EnergySet : public FeatureSet
		{
		public:
			virtual FeatureSetId GetFeatureSetId() { return Features::Energy; }
			virtual double Energy() = 0;
		};

		/* Energy fitting errors depend on the algorithm. */

		class MomentumSet : public FeatureSet
		{
		public:
			virtual FeatureSetId GetFeatureSetId() { return Features::Momentum; }
			virtual double Momentum() = 0;
		};

		/* Momentum fitting errors depend on the algorithm. */

		class Event : public Devices::DeviceMemoryAccessor
		{
		public:
			virtual FeatureSetId FeatureSets() = 0;
			virtual bool HasFeatureSet(FeatureSetId mask) = 0;
			/* Exceptions are thrown if attempting to get unsupported feature sets */
			virtual double UnixTime() = 0;
			virtual long long Run() = 0;
			virtual ParticleIdentificationSet &PID() = 0;
			virtual Hits::EventHitSet &Hits() = 0;
			virtual unsigned int GetTrackCount() = 0;
			virtual TrackSet &Track() = 0;
			virtual FeatureSet &TrackErrors() = 0;
			virtual unsigned int GetShowerCount() = 0;
			virtual ShowerSet &Shower() = 0;
			virtual FeatureSet &ShowerErrors() = 0;
			virtual EnergySet &Energy() = 0;
			virtual FeatureSet &EnergyErrors() = 0;
			virtual MomentumSet &Momentum() = 0;
			virtual FeatureSet &MomentumErrors() = 0;			
		};
	}

	namespace Algorithms
	{
		namespace Features
		{
			FeatureSetId const Trigger = 0x04;			
			FeatureSetId const Track = 0x10;			
			FeatureSetId const Shower = 0x40;			
			FeatureSetId const ParticleIdentification = 0x100;
			FeatureSetId const Energy = 0x1000;			
			FeatureSetId const Momentum = 0x10000;			
		}

		enum ErrorSeverity
		{
			Debug = -1,
			Information = 0,
			Warning = 1,
			Error = 2,
			CriticalError = 3,
			FatalError = 4
		};

		class Logger
		{
		public:
			virtual void Log(ErrorSeverity err_sev, unsigned err_code, const char *pText, unsigned step_identifier) = 0;
		};

		class Algorithm
		{
		public:
			virtual FeatureSetId GetFeatureSetId() = 0;
			virtual bool HasFeatureSet(FeatureSetId mask) = 0;
			virtual Events::Event &Process(Events::Event &ev, Logger &logger) = 0;
		};
	}
}

#endif

