#include <vector>
#include <utility>
#include <string>
#include <stdexcept> 
#include <ctime>
// ROOT includes
//#include "TFile.h" 
//#include "TTree.h"

#include "TFile.h"
#include "TTree.h"

namespace ROAst {

typedef std::runtime_error GeneralException;

//-----------------------------Astro-Catalogue----------------------------------


struct EqAstCoord /** Equatorial astronomic coordinate **/
{
	double RA; /** Right ascension **/
	double Decl; /** Declination **/

};

struct GalactiCoord  /** Galactic astronomic coordinate **/
{
	double AstLat;     /** Galactic latitude **/
	double AstLong;    /** Galactic longitude **/
};

struct GeoCoord /** Geographic coordinate **/
{
	double GeoLat;     /** Geographic latitude **/
	double GeoLong;    /** Geographic longitude **/
    tm GeoTime;         /** Date and time **/
};

class ConvertToGeoCoord  /** Conversion to geo coordinate class **/
{
public:
 ConvertToGeoCoord() ;                         /** default constructor **/

 virtual ~ConvertToGeoCoord() ;             /** Destructor **/

  GeoCoord GalacticToGeoCoord(GalactiCoord c); /** Converts  Galactic astronomic coordinate  to geographic coordinates **/
  GeoCoord EqAstToGeoCoord(EqAstCoord c); /** Converts  equatorial astronomic coordinate  to geographic coordinates **/
};

class ConvertToAstroCoord  /** Conversion to astro coordinate class **/
{
public:
 ConvertToAstroCoord() ;                         /** default constructor **/

  ~ConvertToAstroCoord() ;                 /** Destructor **/
  GalactiCoord EqAstToGalaticCoord(EqAstCoord c);  /** Converts equatorial astronomic coordinate to Galactic astronomic coordinate **/
  EqAstCoord GalaticToEqAstCoord(GalactiCoord c); /** Converts  Galactic astronomic coordinate  to equatorial astronomic coordinate **/
  EqAstCoord GeoToEqAstCoord(GeoCoord c); /** Converts geographic coordinate to equatorial astronomic coordinate  **/
  GalactiCoord GeoToGalaticCoord(GeoCoord c); /** Converts geographic coordinate to equatorial astronomic coordinate  **/

};

struct SpectralMagnitude
{
 double Lambda;  /** Contains the reference lambda  in nanometers for the magnitudes **/    
 double Magnitude; /** Magnitude at the specified lambda **/
};


struct AstroObject  /** Contains the parameters to identify one or more astronomical objects in the catalogue, when the min and max arguments are all equal we are selecting one object **/
{
 EqAstCoord Position;  /** Position of the astronomical object **/
 std::vector<SpectralMagnitude> MaxMagnitudes;  /** Max magnitudes and reference lambda in nanometers  **/  
 std::vector<SpectralMagnitude> MinMagnitudes;  /** Min magnitudes and reference lambda in nanometers  **/  
 double MaxColor;                   /** Max color of the object **/
 double MinColor;                   /** Min color of the object **/
 enum ObjectType {ARTEFACT = 4, PLANET = 3, NEBULA = 2, GALAXY = 1, STAR = 0};  /** Enumerated type of the astronomical objects  **/
 double MaxRedShift;               /** Max red shift of the object **/
 double MinRedShift;               /** Min red shift of the object **/
};


class Catalogue
{
protected:

 std::string CatalogueFile;        /** Catalogue input file **/
 fitsfile  FitsImg;                  /** FITS image name **/
  
public:
   
 std::vector<AstroObject> Container; /** A  container with the astronomical objects of the catalogue **/ 
  
 Catalogue() ;                         /** default constructor **/
   
	
 Catalogue(std::string const &filename); /** Creates a catalogue from a file,a FITS file, a ROOT file **/

 Catalogue(fitsfile const &fitsimg);            /** Creates a catalogue from a FITS image already loaded in ROOT **/

 virtual ~Catalogue() ;                 /** Destructor **/
	
     
   
};

//-----------------------------------Regions---------------------------------------------------

class Region 
{
protected:
 EqAstCoord Centre;        /** Centre of the region **/

public:
    
 Region(EqAstCoord centre);             /** Set the Centre of the region  **/

 virtual ~Region() ;                    /** Destructor **/

 EqAstCoord GetRegCentre() const;       /** Returns Centre - position of centre **/
 void SetRegCentre(EqAstCoord centre);  /** Returns Centre - position of centre **/
 
 
 virtual void WriteRegion(std::string const &file) = 0; /** Writes to a file the selected region **/
 virtual std::vector<AstroObject>  GetInObjects( AstroObject const &filter) const = 0 ; /** Extracts the all the astronomical objects specified by filter present in the selected region **/
 virtual bool ExecuteEvent(AstroObject const &ConditionObject) const = 0  ;  /** Returns true if  the ConditionObject is found in the region **/
 virtual void PopulateRegion() = 0 ; /**  Project the objects on the region populating its container. **/
 virtual void Clear() = 0; /** Clears the region, which can then be reused. **/
 virtual std::string GetRegionShape() const = 0; /** Returns the type of region **/

   
};

//------------------------------------------------------------------------------------------

class Ellipse : public Region  /** Once the region is created can be selected its type **/ 
{
protected:
 EqAstCoord RMaxExtent;     /** One end point of the max radius of the ellipse **/
 double RMinExtent;         /** Min radius  of the ellipse **/
 std::string  RegionShape;  /** The shape of the region **/

public:
 std::vector<AstroObject> EllipseContainer; /** A container with the astronomical object of the ellipse **/


 Ellipse(EqAstCoord rmaxextent, double rminextent); /** Creates an elliptic region **/
      
 virtual ~Ellipse() ;                       /** Destructor **/
   
 virtual void WriteRegion(std::string &file) const; /** Local method to write in a file the selected region **/
   
 EqAstCoord GetRegRMaxExtent() const;  /** Retruns RMaxExtent **/
 double GetRegRMinExtent() const;      /** Retruns RMinExtent **/  
 virtual std::string  GetRegionShape() const;      /** Local method to return the region shape **/

 void SetRMaxExtent(EqAstCoord rmaxextent);        /** Changes RMaxExtent **/
 void SetRMaxExtent(double RMinExtent);            /** Changes RMinExtent **/

 virtual std::vector<AstroObject>  GetInObjects(AstroObject const &filter) const; /** Local method to extract the all the astronomical objects specified by filter present in the selected region **/
 virtual bool  ExecuteEvent(AstroObject  &ConditionObject) const; /** Local method to return true if  the ConditionObject is found in the region **/

 virtual void PopulateRegion() ; /** local mathod to project the objects on the region populating its container. **/
 virtual void Clear() ; /** Local method to clear the region, which can then be reused. **/

};

//------------------------------------------------------------------------------------------

class Circle : public Region
{
protected:
 double RegR; /** Radius of the cicle region **/ 
 std::string  RegionShape;  /** The shape of the region **/

public:
 std::vector<AstroObject> CircleContainer; /** A container with the astronomical object of the circle **/

 Circle(double R); /** Creates an circle region  of radius R  **/
   
 virtual ~Circle() ;                       /** Destructor **/

 virtual void WriteRegion(std::string const &file) const; /** Local method to write in a file the selected region **/
   
 double GetRegR() const;                  /** Retruns RegR **/       
 virtual std::string  GetRegionShape() const;      /** Local method to return the region shape **/
 void SetRegR(double R);                /** Changes RegR **/

 virtual std::vector<AstroObject> GetInObjects(AstroObject const &filter) const; /** Local member to extract the all the astronomical objects specified by filter present in the selected region **/
 virtual bool ExecuteEvent(AstroObject const &ConditionObject) const; /** Local method to return true if  the ConditionObject is found in the region **/
 virtual void PopulateRegion() ; /** local mathod  to project the objects on the region populating its container. **/
 virtual void Clear() ; /** Local method to clear the region, which can then be reused. **/

};

//------------------------------------------------------------------------------------------


class Box : public Region
{
protected:
 EqAstCoord RegVertex;     /** One vertex of the box region **/
 double RegHeight;         /** Height of the box region **/
 double RegWidth;          /** Width of the box region **/
 std::string  RegionShape; /** The shape of the region **/
public:
 std::vector<AstroObject> BoxContainer; /** A container with the astronomical object of the box **/

 Box(EqAstCoord regvertex, double regheight,double regwidth); /** Creates an box region of Height "regheight" and width "regwidth" and vertex "regvertex"**/  
   
 virtual ~Box() ;                       /** Destructor **/

 virtual void WriteRegion(std::string const &file) const; /** Local method to write in a file the selected region **/

 EqAstCoord GetVertex() const;          /** Retruns RegVertex **/
 double GetRegHeight() const;           /** Retruns RegHeight **/
 double GetRegWidth() const;            /** Retruns RegWidth **/
 virtual std::string  GetRegionShape() const;      /** Local method to return the region shape **/

 void SetRegVertex(EqAstCoord regvertex);      /** Changes RegVertex **/
 void SetRegHeight(double regheight);          /** Changes RegHeight **/
 void SetRegWidth(double regwidth);            /** Changes RegWidth **/

 virtual std::vector<AstroObject> GetInObjects(AstroObject const &filter) const; /** Local member to extract the all the astronomical objects specified by filter present in the selected region **/
 virtual bool ExecuteEvent(AstroObject const &ConditionObject) const; /** Local method to return true if  the ConditionObject is found in the region **/
 virtual void PopulateRegion() ; /** local mathod  to project the objects on the region populating its container. **/
 virtual void Clear() ; /** Local method to clear the region, which can then be reused. **/
 };

//------------------------------------------------------------------------------------------


class Line : public Region
{
protected:
  EqAstCoord RegSecondPoint;     /** Position of the second end point of line **/
  std::string RegionShape;  /** The shape of the region **/

public:
 std::vector<AstroObject>  LineContainer; /** A container with the astronomical object of the line **/

 Line(EqAstCoord RegSecondPoint); /** Creates an line region of extreme regsecondpoint and the center on the region**/

 virtual ~Line() ;                /** Destructor **/

 EqAstCoord GetRegSecondPoint() const;    /** Returns RegSecondPoint **/
 virtual std::string  GetRegionShape() const;      /** Local method to return the region shape **/

 virtual void WriteRegion(std::string const &file) const; /** Writes to a file the selected region **/
 void SetRegSecondPoint(EqAstCoord regsecondpoint);  /** Changes RegSecondPoint **/

 virtual std::vector<AstroObject> GetInObjects(AstroObject const &filter) const; /** Local member to extract the all the astronomical objects specified by filter present in the selected region **/
 virtual bool ExecuteEvent(AstroObject const &ConditionObject) const; /** Local method to return true if  the ConditionObject is found in the region **/
 virtual void PopulateRegion() ; /** local mathod  to project the objects on the region populating its container. **/
 virtual void Clear() ; /** Local method to clear the region, which can then be reused. **/
};

//------------------------------------------------------------------------------------------

class Point : public Region
{
protected:
 std::string PointName;    /** Name of the point region **/
 std::string RegionShape;  /** The shape of the region **/

public:
 AstroObject PointContainer;   /** A container with the astronomical objects of the box **/
 Point();/** Creates an point region consisting in the center on of the  region **/
 
 virtual ~Point() ;            /** Destructor **/

 void WriteRegion(std::string const &file) const;  /** Writes to a file the selected region **/
 virtual std::string  GetRegionShape() const;      /** Local method to return the region shape **/

 virtual bool ExecuteEvent(AstroObject const &ConditionObject) const; /** Local method to return true if  the ConditionObject is found in the region **/
 virtual void PopulateRegion() ; /** local mathod  to project the objects on the region populating its container. **/
 virtual void Clear() ; /** Local method to clear the region, which can then be reused. **/
};

//--------------------------Particles-generator------------------------------------



struct CosmicParticle
{
 unsigned long long PDGId; /** Particle Data Group Id  **/
 double Energy; /** Enegrgy of the particle [GeV] **/
 GeoCoord From; /** Direction of the particle  **/
};


class CosmicParticleGenerator
{
protected:
 unsigned long long RunNumber;  /** A int number to identify the simulation RUN **/
 std::string SaveFileName; /** The file where to save the outcome **/ 
public:
  
 CosmicParticleGenerator(std::string const &filename, unsigned long long rn); /** Set the RunNumber and  the output file **/  
 virtual ~CosmicParticleGenerator();                         /** Destructor **/

 virtual std::string GetSaveFileName() const = 0;               /**  Returns the SaveFileName **/
 virtual void SetSaveFileName(std::string const &file) = 0;     /** Set the SaveFileName **/

 virtual TTree *Run(unsigned long long run, unsigned long long particles) = 0;  /** Starts a particle simulation and copy the output in a root-file **/

 virtual TTree *FromFile(std::string cont &file) = 0; /** Import a particle simulation from  file previusly generated **/
};


class NeutralParticleGenerator : public CosmicParticleGenerator
{


protected:

public:
NeutralParticleGenerator();                         /** Default constructor **/

virtual ~NeutralParticleGenerator();                         /** Destructor **/

};



class ChargedParticleGenerator : public CosmicParticleGenerator
{


protected:

public:
ChargedParticleGenerator();                         /** Default constructor **/

virtual ~ChargedParticleGenerator();                         /** Destructor **/

};


class PhotonGenerator : public NeutralParticleGenerator  
{

protected:

public:
PhotonGenerator();                         /** Default constructor **/

virtual ~PhotonGenerator();                         /** Destructor **/

};


class ChargedBarionGenerator : public ChargedParticleGenerator

{

protected:

public:
	ChargedBarionGenerator();                         /** Default constructor **/

virtual ~ChargedBarionGenerator();                         /** Destructor **/

};


class NeutronGenerator : public NeutralParticleGenerator
{

protected:

public:
	NeutronGenerator();                         /** Default constructor **/

virtual ~NeutronGenerator();                         /** Destructor **/

};

class ElectronGenerator : public  ChargedParticleGenerator
{

protected:

public:
ElectronGenerator();                         /** Default constructor **/

virtual ~ElectronGenerator();                         /** Destructor **/

};


class NeutrinoGenerator : public  NeutralParticleGenerator
{
protected:
std::string DetectorFileName; /** The geometry detector file **/ 
public:
 	
 NeutrinoGenerator(std::string const &filename); /** Set the geometry detector file **/ 
 
 virtual ~NeutrinoGenerator();                        /** Destructor **/

};

};

