#include"roast.h"

namespace ROAst{


struct GENHENDatacard   /** Contains all the required physical parameter for GENHEN neutrino simulations program **/ 
 {
	 
 bool                       DecayCode;      /** 0: the standard genhen code w/o tau decay is executed, 1: implemented decay for taus is executed **/    
 bool                       UseDetFile;     /**Enable/Disable the use of the geometry file .det **/
 bool                       LocalCoorsPonitSrcMode; /** point source mode in local coordinates, default is .false. = switched off **/
 bool                       SeedMode;       /** If 0, the seeds are always read from the data-cards if 1, the seeds are read from a file called fort.68  **/
 bool                       PointMode;      /**  Point source mode switch .false. switched off **/
 double                     DedectorLatitude; /** Detector latitude [radians] **/
 double                     SrcZenit;       /** Source zenith  for point source mode  **/
 double                     SrcAzimut;      /** Source azimuth for point source mode **/
 double                     SrcDecli;       /** Source declinaion for point source mode **/
 double                     SpectralIndex;  /** spectral index of power law generation spectrum **/
 int                        RunNumber;      /** Run number **/
 int                        Target;         /** Target type 0 = std. rock **/
 int                        EventType;      /** Selecting way in which generation volume is calculated according to lepton produced in CC interaction **/
 int                        KinetCut;       /** Kinematic cut **/
 int                        WeiteOptions;   /** 0= Only write out events at the can, 1= writes all events 3= only events in the can **/
 int                        NrEnergyBin;    /** Number of energy bins for which generation volume is calculated **/
 int                        WeightID;       /** Weight ID **/
 std::pair<bool,bool>       CrossSectParam; /** Parameterization of the cross section (1) = parametrization mode: 1=ON; 0=OFF (2) = parametrizaion model: 1=CTW    **/  
 std::pair<int,int>         NrEvents;       /** (1) number of events to generate, (2) Exponent of the number of events (i.e. NrEvents(1)Exp(NrEvents(2))) **/
 std::pair<int,int>         FluxTag;        /** Atmospheric flux settings **/
 std::pair<int,int>         IParticle;      /** (1) JETSET particle type, (2)  2 = CC interaction 3 = NC interaction **/
 std::pair<int,int>         PDF;            /** PDF Choice **/          
 std::pair<int,int>         Particle;       /** Neutrino type **/ 
 std::pair<int,int>         Flux;           /** Flux choice **/
 std::pair<int,double>      NrAbsorbLengths;/** (1) Number of absorption lengths, (2)  Absorption length [m] **/
 std::pair<double,double>   BedAndSeaLevel; /** z-level of the sea bed [m], z-level of the water surface [m] **/
 std::pair<double,double>   GENHENCut;      /** (1) Neutrino direction precut distance from the can in [m], 
                                                (2) Muon energy threshold [GeV] **/
 std::vector<int>           MuModel;        /** (1) 1 = activates prompt mu  2 = MUM (the only one that can propagate tau neutrinos) 
                                                (2) 1/0-Enable/Disable multiple scattering (not in MUM)
                                                (3) is X in 10^-X for defining the maxrange as the range for which the surviving probability is 10^-X Recommended: X = 2 **/
 std::vector<int>           FluxParameters; /** (1) average Solar modulation for atmospheric Bartol flux, (2) has meaning only for  (1)=5=FLUKA_NEW
						(3) PROMPT flux: 1 = OFF (default), 2 = ON,(4) PROMPT flux model; for instance, 3 is max RQPM prompt flux **/
 std::vector<int>           Seed;           /** Initial random seed, (2) for RANLUX use, (3) for RANLUX use **/
 std::vector<int>           MuonMode;       /** Muon mode propagation **/
 std::vector<int>           EarthProp;      /** (1)for propagation in the Earth 0 = no prop 1 = propagation  is activated
                                               (2) = <P> for setting the energy threshold at which propagation is activated according (threshold energy value in GeV)
                                               (3) = to switch off=0 on=1 information on all propagated   neutrinos through the Earth **/
 std::vector<double>        EnengyCut;      /** (1)  E_min [GeV], (2)  E_max [GeV],(3)  cos_min [nadir angle],(4)  cos_max **/
 std::vector<double>        CanSize;        /** the Can size in meters (xmin[m], zmax[m], radius[m]) **/
 };
struct GENHENSysConfig /** Contains all the paths for GENHEN  neutrino simulations program **/
  { 
 std::string GENNEU_PATH; 
 std::string ANTRS_PROD; 
 std::string GENNEU_V;
 std::string EVOFIL;  
 std::string GEOFIL;  
 std::string RSQPATH;
 std::string CTEQ6_DATA; 
 std::string MUSICPATH; 
  };


class GENHENGenerator : public NeutrinoGenerator
{
protected:
 std::string DataCardFile;  /** The file where to import the datacard **/
 GENHENDatacard datacard;   /** Physical parameters of GENHEN **/
 GENHENSysConfig Paths;     /** Paths of the genhen neutrino simulations program **/
 public:

 GENHENGenerator();  /** Default generator **/

 virtual ~GENHENGenerator() ; /** Default destructor **/
   
 virtual TTree *Run(unsigned long long run, unsigned long long particles) ; /** Create a neutrino simulation using GENHEN and copy the output in a root-file **/

 virtual TTree *FromFile(std::string cont &file) ; /** Import a neutrino simulation from  file previusly generated by GENHEN **/

 GENHENSysConfig GetRunPaths() const;                    /** Returns the current paths **/
 GENHENDatacard GetDatacard() const;                    /** Returns the current data card **/
 void SetDataCard(GENHENDatacard const &datacard);      /** Set the datacard for the simulation **/
 void LoadDataCard(std::string const &file);            /** Load the datacard  from file **/
 void SetSysConfig(GENHENSysConfig const &paths);       /** Set the paths for the simulation **/
 

};
};
