"""
The main read-evaluate-print loop of the TAP shell, plus the startup.
"""

from __future__ import with_statement

import os
import re
import readline
import sys
import threading
import time

from gavo.votable import tapquery

from tapsh import commandbase
from tapsh import common
from tapsh import context
from tapsh import metashelf


def ensureEnvironment(opts):
	"""sets up the working environment.

	The function returns a function maintaining external invariants
	("cleanup") that should be called before exiting.
	"""
	if not os.path.isdir(common.TAPSH_DIR):
		os.mkdir(common.TAPSH_DIR)

	metashelf.ensureStorage()

	historyFName = os.path.join(common.TAPSH_DIR, "history")
	try:
		readline.read_history_file(historyFName)
	except IOError:
		pass
	
	def cleanup():
		readline.write_history_file(historyFName)

	return cleanup


def evaluate(ctx, input):
	"""evaluates input and usually prints some result.
	"""
	input = input.strip()
	if input.startswith("#") or not input: # ignore empty input
		return
	return ctx.commands.getCommand(input.split()[0])(ctx, input)


def _iterStdinInput(ctx):
	prompt = ""
	if common.ON_TERMINAL:
		prompt = "tapsh> "
	while True:
		try:
			yield raw_input(prompt)
		except EOFError: # ^D in raw_input
			common.output('')
			return
		except KeyboardInterrupt:
			common.output('')


def _iterScriptInput(ctx):
	try:
		inF = open(ctx.scriptFile)
	except IOError, msg:
		raise common.FatalError("Cannot open script file %s"%(str(msg)))
	buffer = []
	while True:
		inLine = inF.readline()
		if inLine=='':
			break
		inLine = inLine.strip()

		if inLine.endswith("\\"):
			buffer.append(inLine[:-1])
			continue
		else:
			buffer.append(inLine)
		yield " ".join(buffer)
		buffer = []
	inF.close()
	if buffer:
		raise common.FailedCommand("Script file ends with continuation character.")


def iterInputs(ctx):
	if ctx.scriptFile is not None:
		return _iterScriptInput(ctx)
	else:
		return _iterStdinInput(ctx)


def repl(ctx):
	for inLine in iterInputs(ctx):
		if ctx.echoInput:
			print inLine
		try:
			res = evaluate(ctx, inLine)
		except common.FailedCommand, ex:
			common.outputError(str(ex)+"\n")

		except common.FatalError:
			raise

		except tapquery.RemoteError, ex:
			common.outputError("(remote:) %s"%str(ex))

		except tapquery.NetworkError, ex:
			common.outputError("(network:) %s"%(str(ex)))

		except tapquery.WrongStatus, ex:
			common.outputError("(remote:) %s"%str(ex))
			common.outputError(re.sub("<[^>]+>", "", str(ex.payload)))

		except:
			common.outputError("Internal Error; see traceback above.  "
				"You'll probably want to report this", dumpExc=True)

		if ctx.exitValue is not None:
			break
	else: # Normal end of input
		ctx.exitValue = 0
	return ctx.exitValue


def _printVersionAndExit(option, opt, value, parser):
	print common.VERSION
	sys.exit(0)


def parseCommandLine():
	from optparse import OptionParser
	parser = OptionParser(usage="%prog [options] [<script>] -- a shell to query"
		" VO TAP servers")
	parser.add_option("--rst-ref", help="Output reference documentation in"
		" reStructured text and exit (for maintainers).", action="store_true",
		dest="printReference")
	parser.add_option("-N", "--no-samp", help="Disable SAMP interface"
		" (mainly for debugging)", action="store_false", dest="runSAMP",
		default=True)
	parser.add_option("--echo-input", help="Echo commands as they are"
		" executed (may be nice for script operation)",
		action="store_true", dest="echoInput", default=False)
	parser.add_option("--version", help="Write version to stdout and exit",
		action="callback", callback=_printVersionAndExit)
		
	opts, args = parser.parse_args()

	opts.scriptFile = None
	if len(args)>1:
		parser.print_help(file=sys.stderr)
		sys.exit(1)
	if len(args)==1:
		opts.scriptFile = args[0]
		common.ON_TERMINAL = False
	return opts


def realMain():
	opts = parseCommandLine()

	if common.ON_TERMINAL:
		print "Tapsh %s, http://docs.g-vo.org/tapsh"%common.VERSION

	cleanup = ensureEnvironment(opts)
	ctx = None
	try:
		from tapsh import localcommands, tapcommands
		ctx = context.Context(commandbase.Commands(
			[localcommands, tapcommands]), opts)
		if opts.printReference:
			ctx.commands.printReference()
			sys.exit(0)

		res = repl(ctx)

		ctx.saveState()
	finally:
		if ctx:
			ctx.cleanup()
		cleanup()
		# have some grace time to let SAMP threads stop gracefully
		# (there's nothing we can do to force them anyway)
		for ct in range(10):
			time.sleep(0.2)
			if len(list(threading.enumerate()))==1:
				break
		else:
			pass
			#print "Stale threads"
	sys.exit(res)


def main():
	common.ON_TERMINAL = os.isatty(sys.stdin.fileno())
	try:
		realMain()
	except common.FatalError, msg:
		sys.stderr.write("FATAL: %s\n"%msg)
		sys.exit(1)


if __name__=="__main__":
	main()
