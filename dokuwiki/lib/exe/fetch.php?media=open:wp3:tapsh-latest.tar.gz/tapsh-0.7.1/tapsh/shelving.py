"""
Common helpers for metashelf implementations.

metashelves do the local storage of tapsh: server list, active jobs, and
such.

There are two implementations of those right now: File-based and sqlite,
where sqlite is the older one.  The file-based one was created to let
tapsh work within jython and thus will probably become the only
one supported; but let's see.
"""


import random
import urllib

from gavo import votable
from tapsh import common


GLOTS_SERVERS = (common.GLOTS_BASE+"/servers/form?__nevow_form__=genForm"
	"&_DBOPTIONS_LIMIT=10000&_FORMAT=VOTable")


def getServerListFromNet():
	f = urllib.urlopen(GLOTS_SERVERS)
	data, metadata = votable.load(f)
	f.close()
	return [(row[0], row[1]) for row in data]


_syllables = [c+v for v in 'aeiou' for c in 'bcdfglmnprstvwxz']
def makeNick():
	"""returns a random, hopefully cute-sounding nickname.

	There are 512000 nicks this function currently generates.  This may
	be a bit tight if people run many jobs and never clean up.  Hm...
	"""
	return "".join([random.choice(_syllables),
		random.choice(_syllables), random.choice(_syllables)])
