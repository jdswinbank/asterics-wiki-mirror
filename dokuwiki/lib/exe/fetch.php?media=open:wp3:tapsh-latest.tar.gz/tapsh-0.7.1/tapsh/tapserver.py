"""
Almost a facade for a TAP server.
"""

import urllib

from gavo import votable

from tapsh import common
from tapsh import metashelf



class TAPServer(object):
	"""A metadata collection for a TAP server.
	"""
	_tablesCache = None

	def __init__(self, ivoId, accessURL):
		self.ivoId, self.accessURL = ivoId, accessURL

	def createJob(self, query):
		return votable.ADQLTAPJob(self.accessURL, query)

	def getTables(self):
		if self._tablesCache is None:
			tablesURL = (common.GLOTS_BASE+
				"/showtables/qp/%s?_FORMAT=VOTable&VERB=3"%urllib.quote(self.ivoId))
			f = urllib.urlopen(tablesURL)
			data, meta = votable.load(f)
			f.close()
			self._tablesCache = [r[1] for r in data]
		return self._tablesCache


