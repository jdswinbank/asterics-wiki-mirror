"""
Commands that deal with local state.
"""

from __future__ import with_statement

import re
import sys
import time
import urllib
import webbrowser

from gavo.imp import pyparsing
from gavo import utils
from gavo import votable
from gavo.votable import tapquery

from tapsh import commandbase
from tapsh import common
from tapsh import metashelf


class Namer(object):
	def __init__(self):
		self.namesReturned = set()
	
	def get(self, suggestion):
		ct = 0
		base = suggestion
		while suggestion in self.namesReturned:
			ct += 1
			suggestion = "%s-%02d"%(base, ct)
		return suggestion


def getSAMPClients(ctx):
	"""returns a dictionary name -> client-id for clients subscribed to
	VOTables.
	"""
	if ctx.samp is None:
		return {}
	res = []
	n = Namer()
	for id in ctx.samp.getSubscribedClients("table.load.votable"):
		clientName = n.get(ctx.samp.getMetadata(id).get("samp.name", "Unnamed"))
		clientName = clientName.replace(" ", "_")
		res.append((clientName, id))
	return dict(res)


def openWebbrowser(url):
	"""opens a webbrowser for url or, failing that, asks the user to do that.
	"""
	try:
		webbrowser.open_new_tab(url)
	except:
		raise common.FailedCommand("Cannot open a web browser (%s).  Please"
			" open\n%s manually."%(sys.exc_info()[0].__name__, url))


class Broadcast(commandbase.CommandWithNickArg):
	clidoc = ("[<nick>] -- broadcasts a result to all connected SAMP clients.")
	longdoc = """
	The URL of the current or selected job's result will be sent to
	all SAMP clients connected and listening to table.load.votable.
	The function will error out if SAMP has been disabled or if no
	result currently exists.
	"""

	def execute(self, ctx, nick=None):
		job = self.getJob(ctx, nick)
		if ctx.samp is None:
			raise common.FailedCommand("No SAMP client running")
		if job.phase!=tapquery.COMPLETED:
			raise common.FailedCommand("Job must be COMPLETED for results.")
		ctx.samp.enotifyAll("table.load.votable", 
			url=job.getResultURL())


class Send(commandbase.CommandWithNickArg):
	clidoc = ("[<nick>] to <recpient> -- sends a result to a SAMP client"
		" <recipient>")
	longdoc = """
	Send works like broadcast, except that you can select the SAMP
	client to send to.  Try the tab key to see the client names
	assigned by tapsh.  The first topcat instance will always be
	called topcat, though.

	The client list is only updated every 10 seconds, so you may
	have to wait a bit if you hit Tab and only then started the
	destination client.
	"""

	# result of getSAMPClients at cl parse time
	curSAMPClients = {}
	lastClientUpdate = None

	def _updateClients(self, ctx):
		if (self.lastClientUpdate is None
				or time.time()-self.lastClientUpdate>10):
			self.curSAMPClients = getSAMPClients(ctx)
			self.lastClientUpdate = time.time()

	def _getSAMPCompletions(self, ctx, parts):
		if parts[-2]=="to":
			self._updateClients(ctx)
			return common.getMatching(parts[-1], self.curSAMPClients)
		else:
			return common.getMatching(parts[-1], ["to "])

	def getCompletions(self, ctx, parts):
		if len(parts)==2:
			nicks = [n+" " for n in metashelf.getNicksWithPrefix(ctx, parts[-1])]
			if "to".startswith(parts[-1]):
				nicks.append("to ")
			return nicks
		else:
			return self._getSAMPCompletions(ctx, parts)

	def _getCLIGrammar(self):
		recipient = pyparsing.Word(pyparsing.alphanums+"_-+")
		recipient.setName("SAMP client name")
		toSymbol = pyparsing.Suppress(pyparsing.CaselessKeyword("to"))
		return ( self.swallowCommand 
			+ ( ( toSymbol + recipient )
				| ( self.nickSymbol + toSymbol + recipient ) ) )
	
	def execute(self, ctx, *args):
		if len(args)==1:
			nick, recipName = None, args[0]
		else:
			nick, recipName = args
		if ctx.samp is None:
			raise common.FailedCommand("No SAMP client running")
		self._updateClients(ctx)
		job = self.getJob(ctx, nick)
		if job.phase!=tapquery.COMPLETED:
			raise common.FailedCommand("Job must be COMPLETED for results.")
		try:
			dest = self.curSAMPClients[recipName]
		except KeyError:
			raise common.FailedCommand("SAMP client '%s' not found"%recipName)
		ctx.samp.enotify(dest,
			"table.load.votable",
			url=job.getResultURL())


class Help(commandbase.Command):
	clidoc = "-- gives a short synopsis of available commands"
	longdoc = """
	Without an argument, help prints a synopsis of the commands available.
	With an argument, it will print a longer explanation of what the
	command does.
	"""
	def _getCLIGrammar(self):
		command = pyparsing.Word(pyparsing.alphanums)
		command.setName("Command name")
		return self.swallowCommand + pyparsing.Optional(command)
	
	def getCompletions(self, ctx, parts):
		if len(parts)!=2:
			return []
		return common.getMatching(parts[-1], list(ctx.commands))

	def execute(self, ctx, command=None):
		if command is None:
			common.output("\n".join(
				sorted("%s %s"%(key, val.clidoc) 
					for key, val in ctx.commands.iteritems())))
		else:
			common.output(ctx.commands.getCommand(command).getLongdoc())


class Quit(commandbase.Command):
	clidoc = "-- shuts down tapsh"
	longdoc = """
	You don't need help for this, do you?
	"""

	def execute(self, ctx):
		ctx.exitValue = 0


class Server(commandbase.CommandWithServerArg):
	clidoc = "[<ivo-id>] -- gets/sets the current server (try TAB for ids)"
	longdoc = """
	tapsh almost always has a current server, the one new jobs are
	created on.  Only TAP servers known to tapsh can be set (i.e.,
	you cannot just grab an ivo id from somewhere).  Use the `refreshservers
	command`_ to update tapsh's internal list of TAP servers from GAVO's
	global TAP schema.

	The ids used by tapsh are IVOA identifiers (except where you assigned
	them yourself using ``addserver``).  These are, admittedly, somewhat 
	unwieldy, but that's what tab completion is for.
	"""

	def execute(self, ctx, serverId=None):
		if serverId is None:
			if ctx.currentServer is None:
				common.output("No server selected")
			else:
				common.output(ctx.currentServer.ivoId)
		else:
			try:
				ctx.setServer(serverId)
			except KeyError:
				raise common.FailedCommand("Unknown TAP server '%s'"%serverId)


class RefreshServers(commandbase.Command):
	clidoc = "-- update the list of TAP servers from the GAVO DC"
	longdoc = """
	tapsh relies on the resources of GAVO's global TAP schema (GloTS),
	a registry of TAP services and the tables contained within them.
	When run for the first time, it will retrieve a list of TAP
	services known to GloTS and keep a local copy.

	Since new TAP servers come around now and then, you should rund
	refreshservers periodically to keep up to date.  A clear sign
	you should do so is when the server command complains about
	unknown servers.
	"""

	def execute(self, ctx):
		metashelf.refreshServerList()


class Ls(commandbase.Command):
	clidoc = "-- lists known jobs"
	longdoc = """
	tapsh keeps a list of jobs started but not deleted.  The ls command
	lets you inspect that list.  From this list, you can see what
	jobs you can make the current job again using the job command.

	The phases given in ls are the phases it found when tapsh last 
	looked.  To have ls show current remote phases, use the update 
	command.
	"""

	def execute(self, ctx):
		curNick = ctx.currentJob and ctx.currentJob.nickname
		for job in metashelf.iterJobs(ctx):
			fmted = common.formatJob(job)
			if job.nickname==curNick:
				fmted = fmted+" *"
			common.output(fmted)


class Job(commandbase.CommandWithNickArg):
	clidoc = " [<nick>] -- gets/sets current job"
	longdoc = """
	A TAP job has rich server-side metadata, in particular the query
	issued.  The job command shows a synopsis of this data, retrieved
	from the server.  It updates the "last known" phase information, too.

	Without an argument, job shows the current job's metadata, otherwise
	that of the named job.

	Certain DSA servers produce malformed responses that lead tapsh to believe
	the job was dead on the remote side.  Don't worry about this, that's
	just a harmless protocol mismatch.
	"""
	def formatInfo(self, info):
		if "errMsg" not in info:  # job ok server-side
			nickname = info["nickname"]
			jobId = info["jobId"]
			phase = info["phase"]
			destdue = info["destruction"].isoformat()
			ed = str(int(info["executionDuration"]))
			query = info["parameters"].get("query", "<not given>")
			return ("Job nicked %(nickname)s (remote id %(jobId)s)\n"
				"phase %(phase)s, destruction due %(destdue)s, time limit %(ed)s\n"
				"--------------------------------------\n%(query)s"%locals())
		else:
			return ("Job nicked %(nickname)s, (remote id %(jobId)s)\n"
				"Dead Server-Side (message: %(errMsg)s)")%info

	def execute(self, ctx, nick=None):
		job = self.getJob(ctx, nick)
		if nick is not None:
			ctx.currentJob = job
		try:
			info = job.info
		except tapquery.Error, ex:  # job gone server-side, most likely
			info = {"errMsg": str(ex), "jobId": job.jobId,
				"phase": "DESTROYED"}
		info["nickname"] = job.nickname
		metashelf.updateJob(ctx, job, info["phase"])
		common.output(self.formatInfo(info))


class Purge(commandbase.Command):
	clidoc = " |failed|all -- deletes server-gone/failed/all jobs"
	longdoc = """
	Manually deleting jobs becomes tedious, in particular when
	experimenting.  The purge command lets you delete all job
	removed on the server side (default; you will need to run update
	to make tapsh aware of server-side destructions), or additionally
	jobs in error phases (i.e., those in ERROR or ABORTED phases) when
	the failed keyword is given.

	``purge all`` destroys all known jobs.  This, in particular, means
	you lose all results still stored server-side.
	"""

	def _getCLIGrammar(self):
		selector = ( pyparsing.Keyword("failed") 
			| pyparsing.Keyword("all")
			| pyparsing.StringEnd())
		return self.swallowCommand + selector
	
	def getCompletions(self, ctx, parts):
		if len(parts)!=2:
			return []
		return common.getMatching(parts[-1], ["all", "failed"])
	
	def execute(self, ctx, criterion=None):
		if criterion is None:  # remove everything gone server-side
			toDelete = metashelf.getNicksInPhases(ctx, ["DESTROYED"])
		elif criterion=="all":
			toDelete = metashelf.getNicksWithPrefix(ctx, "")
		elif criterion=="failed":
			toDelete = metashelf.getNicksInPhases(ctx, [tapquery.ABORTED,
				tapquery.ERROR])
		# else interal error
		for nick in toDelete:
			with common.progress("Deleting %s... "%nick):
				ctx.commands.getCommand("delete")(ctx, "delete %s"%nick)


class Save(commandbase.CommandWithNickArg):
	clidoc = '"<file name>" [<nick>] -- save the job\'s result to a local file.'
	longdoc = """
	The save command lets you retrieve a completed job's result and store
	it in a local file.  You must enclose the local file name in double
	quotes, giving full paths is legal.
	"""

	def _getCLIGrammar(self):
		return ( self.swallowCommand
			+ common.quotedString
			+ pyparsing.Optional(self.nickSymbol))
	
	def getCompletions(self, ctx, parts):
		if len(parts)==2:
			if not parts[-1]:
				return ['"']
			elif parts[-1].startswith('"') and not parts[-1].endswith('"'):
				return parts[-1]+'"'
			else:
				return ['"tap_result.vot" ']
		elif len(parts)==3:
			return metashelf.getNicksWithPrefix(ctx, parts[-1])
		else:
			return []
	
	def execute(self, ctx, destName, nick=None):
		job = self.getJob(ctx, nick)
		destName = destName.strip('"')
		try:
			inF = job.openResult()
		except (IOError, tapquery.Error), msg:
			raise common.FailedCommand("Could not open job result (%s)"%(
				str(msg)))
		with open(destName, "w") as outF:
			while True:
				buf = inF.read(1000000)
				if buf=='':
					break
				outF.write(buf)


class Dump(commandbase.CommandWithNickArg):
	clidoc = " [<nick>] -- dumps the query result to the console"
	longdoc = """
	If a job has a result, dump retrieves it and formats it as a rough
	ASCII table.  The result is not beautiful, and no attempt is made
	to accomodate to screen widths.  Thus, for nontrivial result sets,
	you should really use "send to topcat" or similar.
	"""
	@staticmethod
	def _stringifyAll(table):
		normPat = re.compile("[\r\n\t]+")
		return [tuple(normPat.sub(" ", str(v)) for v in row) for row in table]

	def execute(self, ctx, nick=None):
		job = self.getJob(ctx, nick)
		if job.phase!=tapquery.COMPLETED:
			raise common.FailedCommand("Results can only be dumped on COMPLETED jobs")
		try:
			f = job.openResult()
			try:
				data, metadata = votable.load(f)
			finally:
				f.close()
		except (IOError, tapquery.Error, votable.VOTableParseError), msg:
			raise common.FailedCommand("Could not open job result (%s)"%(
				str(msg)))
		headline = tuple(f.name for f in metadata)
		print utils.formatSimpleTable([headline]+self._stringifyAll(data))
	

class Nick(commandbase.Command):
	clidoc = "<nick name> -- sets the current job's nick name"
	longdoc = """
	Using nick, you can assign mnemonic names to the current job.  This is
	particularly useful in scripts, since it lets you refer to jobs previously
	created in, e.g., upload commands.

	If a job other than the current one already has the given nick, it is deleted
	on the server.  Again, this is what you want in scripts.

	Nicknames must consist exclusively of ASCII alphabetic characters
	(a-z, A-Z).  The automatically assigned nicknames are always
	six lowercase characters long, with consonants and vowels alternating
	(in the hope that the result is pronounceable).  It is a good idea
	to use names constructed differently for your fixed nicks.

	Example::

		select * from table1
		nick FirstRes
		run
		select * from table1 join tap_upload.uploaded
		upload result FirstRes as uploaded
		run
	"""
	def _getCLIGrammar(self):
		return self.swallowCommand + self.nickSymbol
		
	def execute(self, ctx, newNick):
		if ctx.currentJob is None:
			raise common.FailedCommand("No current job")
		if ctx.currentJob.nickname==newNick:
			return

		try:
			job = metashelf.getJobByNick(ctx, newNick)
		except KeyError: # no old job with nick, all's fine
			pass
		else:
			# If there already is a job with the new nick name, it needs
			# to be deleted since it will become inaccessible.
			try:
				metashelf.removeJob(ctx, job)
				job.delete()
			except tapquery.Error: # failed deletion: not our problem
				pass

		metashelf.renameJob(ctx, ctx.currentJob.nickname, newNick)
		ctx.currentJob.nickname = newNick


class Metasearch(commandbase.Command):
	clidoc = "[<colstuff> [/ <tablewords>]] -- search for queriable columns"
	longdoc = """
	GAVO's Global TAP Schema GloTS offers a web interface for locating tables
	accessible using TAP.  The metasearch command opens a web browser
	window letting you search by UCDs, table keywords and column keywords.

	metasearch by itself just opens a browser window with GloTS' form interface.
	If you give argument(s), you will be sent to a result page.  A
	first argument that contains dots or a semicolon will be interpreted
	as a UCD pattern (* and ? work as in shell patterns), anything else
	will be column description words.
	"""

	def _getCLIGrammar(self):
		tableDesc = ( pyparsing.Suppress( pyparsing.Literal("/") )
			+ pyparsing.SkipTo(pyparsing.LineEnd()) )
		stuff = pyparsing.SkipTo(
			tableDesc | pyparsing.LineEnd() )
		return ( self.swallowCommand
			+ pyparsing.Optional( stuff )
			+ pyparsing.Optional(tableDesc) )

	def execute(self, ctx, *args):
		destURL = common.GLOTS_BASE+"/plain/form"
		urlArgs = {'__nevow_form__': 'genForm'}

		# column words, may contain a UCD
		if len(args)>0 and args[0]:
			parts = args[0].split()
			# does the first particle look like a ucd?
			if "." in parts[0] or ";" in parts[0]:
				urlArgs["ucd"] = "~"+parts[0]
				urlArgs["columnwords"] = " ".join(parts[1:])
			else:
				urlArgs["columnwords"] = " ".join(parts)
	
		if len(args)>1 and args[1]:
			urlArgs["tablewords"] = args[1]
		
		if len(urlArgs)>1: # search items were given:
			destURL = destURL+"?"+urllib.urlencode(urlArgs)

		openWebbrowser(destURL)


class Tables(commandbase.CommandWithServerArg):
	clidoc = "[<ivo-id>] -- inspect a server's tables in a web browser window"
	longdoc = """
	GAVO's global TAP schema offers a web interface for inspecting the
	tables on the current server.  The table command opens a web browser
	window that shows the tables available and lets you inspect the table
	schemata.
	"""
	def execute(self, ctx, ivoId=None):
		if ivoId is None:
			if ctx.currentServer is None:
				raise common.FailedCommand("No server selected")
			else:
				ivoId = ctx.currentServer.ivoId
		openWebbrowser(common.GLOTS_BASE+"/showtables/qp/%s"%
			urllib.quote(ivoId))


class Wait(commandbase.Command):
	clidoc = "<seconds> -- just waits for the specified number of seconds"
	longdoc = """
	The wait command is a cheap hack to allow scripts to pause a bit before
	exiting.  The purpose of this is to give SAMP clients a chance to complete
	their dialogs with the tapsh.  Admittedly a command wait_for_samp_to_complete
	would be better, but even for SAMP transactions that tapsh has initiated
	that is not trivial.  Hence, this hack.
	"""
	def _getCLIGrammar(self):
		duration = pyparsing.Word("0123456789")
		duration.setName("Number of seconds")
		return self.swallowCommand + duration
	
	def getCompletions(self, ctx, parts):
		return []

	def execute(self, ctx, noSec):
		import time
		time.sleep(int(noSec))


class Addserver(commandbase.Command):
	clidoc = "<id> <accessurl> -- adds a non-registred server to the server list"
	longdoc = """
	To use non-registred servers, you can manually add them using their
	access URL, which is the URL of the query endpoint without any sync or
	async.

	The server id can be any string not containing whitespace.

	Note that manually added servers will be lost when you use the refreshServers
	command.  You could write a short script to add your preferred local
	servers if you really wanted to, but the correct way is to bug the
	server operators to register their servers.  There's no documented way
	to remove a server locally added except by removing them all using
	refreshServers.
	"""
	def _getCLIGrammar(self):
		localId = pyparsing.Regex(r"[^\s]+")
		localId.setName("Id you want to refer the server as")
		accessURL = pyparsing.Regex(r"http://[^\s]+")
		accessURL.setName("HTTP Access URL (without any sync or async)")
		return self.swallowCommand + localId + accessURL
	
	def getCompletions(self, ctx, parts):
		return []
	
	def execute(self, ctx, localId, accessURL):
		metashelf.addServer(localId, accessURL)
		metashelf.saveServerList()

