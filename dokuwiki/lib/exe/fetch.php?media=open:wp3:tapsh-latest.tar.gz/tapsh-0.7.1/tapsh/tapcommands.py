"""
Commands dealing with tap jobs.
"""

from __future__ import with_statement

import datetime
import glob
import os
import readline
import urllib

from gavo.imp import pyparsing
from gavo.votable import tapquery

from tapsh import common
from tapsh import commandbase
from tapsh import metashelf


class Select(commandbase.Command):
	clidoc = "<query tail> -- creates a new query on the current server"
	longdoc = """
	The select command creates a new job on the current server.  This does
	not start the execution of the query, it just creates a job.  No syntax
	checks are performed locally, and the servers will usually only check
	the syntax when the query is actually executed.

	The job created will be the new current job.

	tapsh will automatically make up a nickname for the job.  You can change
	the local nickname using the nick command.
	
	Since it is such a common operation, there is a shortcut to immediately
	process the job and send its result to topcat on successful completion: Just
	append a semicolon (;) to the query.  This is equivalent to the sequence::

		select foo from bar
		run
		send to topcat
	
	Similarly, if you append a bang (!) to a query, the result is
	immediately retrieved and dumped.
	
	Some TAP servers run DSA.  In late 2010, those still speak an early dialect
	of ADQL.  You will notice this when, on executing the select statement,
	you will receive some error message talking about ADQL/X for valid ADQL.
	Mostly, you can fix this by prefixing all column names with the table
	name, like so::

	  select t.ra from dsaControlledTable as t where t.dec<-89
	"""

	def _completeTable(self, ctx, parts):
		if ctx.currentServer is None:
			return []
		return common.getMatching(parts[-1], ctx.currentServer.getTables())

	_cuePhrases = {
		'from': "_completeTable",
		'select': None,
		'where': None}

	def getCompletions(self, ctx, parts):
		# We don't want a complete ADQL parser in here.  So, we go on "cues".
		# Right now, let's see if there's a "from" somewhere in sight.
		for p in reversed(parts):
			if p in self._cuePhrases:
				break
		else:
			return []
		completer = self._cuePhrases[p]
		if completer:
			return getattr(self, completer)(ctx, parts)
		return []

	def execute(self, ctx, query):
		lastChar = query[-1]
		immediateRun = lastChar==";" or lastChar=="!"
		if immediateRun:
			query = query[:-1]
		ctx.createJob(query)
		if immediateRun:
			ctx.commands.getCommand("run")(ctx, "run")
			if ctx.currentJob.phase==tapquery.COMPLETED:
				if lastChar==";":
					ctx.commands.getCommand("send")(ctx, "send to topcat")
				elif lastChar=="!":
					ctx.commands.getCommand("dump")(ctx, "dump")

	def parseCommandLine(self, commandLine):
		return (commandLine,)


class Run(commandbase.CommandWithNickArg):
	clidoc = "[<nick>] -- starts a job and blocks until finished"
	longdoc = """
	Without an argument, run starts the current job, otherwise the named
	job is run.  Tapsh will block until the job has reached a final
	phase.

	You can abort the job started by run by hitting ^C.  There currently
	is no way to "background" a running job.  Pester us if you want this.

	Use the start command to start a job and immediately have a prompt
	again.

	After run, the job will be in a final state.  Use the `job command`_ 
	to see which it is.
	"""
	def execute(self, ctx, nick=None):
		job = self.getJob(ctx, nick)
		try:
			try:
				job.run()
			except KeyboardInterrupt:
				ctx.currentJob.abort()
		finally:
			metashelf.updateJob(ctx, job, job.phase)


class Start(commandbase.CommandWithNickArg):
	clidoc = "[<nick>] -- starts a job server-side and immediately returns"
	longdoc = """
	Without an argument, the current job is started, otherwise the named
	job is started.  Contrary to the the run command, you immediately 
	get a tapsh prompt again.  You can check the job's status using the
	job command.
	"""

	def execute(self, ctx, nick=None):
		job = self.getJob(ctx, nick)
		job.start()
		metashelf.updateJob(ctx, job, job.phase)


class Delete(commandbase.CommandWithNickArg):
	clidoc = "[<nick>] -- destroys a job server-side and locally"
	longdoc = """
	Without an argument, the current job is deleted, otherwise the named
	job is deleted.  If the job is running, it is aborted.

	It is generally considered nice to delete a job when done with it.  You
	can use the purge command to delete many jobs at a time for convenience.
	"""

	def execute(self, ctx, nick=None):
		job = self.getJob(ctx, nick)
		try:
			job.delete()
		except tapquery.Error, ex:
			if getattr(job, "lastPhase", None)!="DESTROYED":
				common.outputInfo("There was a problem while deleting the job"
					" from the server\n(%s).\nYou probably do not want to worry"
					" about this."%str(ex))
		metashelf.removeJob(ctx, job)
		if nick is None:  # kill the current Job.
			ctx.currentJob = None


class Update(commandbase.Command):
	clidoc = "[all] -- updates phases for non-finished or all jobs"
	longdoc = """
	The update command causes tapsh to query the servers of all jobs
	not known to tapsh to be in a final phase (i.e., those in PENDING, 
	QUEUED, or EXECUTING) for their phases and update their metadata
	accordingly.

	With the optional ``all`` argument, even jobs in final phases are
	updated.  This is mainly to detect jobs deleted server-side (e.g.,
	because their destruction time has passed).  These will then go
	to the (tapsh-internal) DESTROYED phase.

	Note that tapsh will not monitor its jobs automatically, so the output
	of the ls command may be out of date.  The "known" phase of a job will
	be updated by the run and job commands as well.
	"""
	def _getCLIGrammar(self):
		selector = (pyparsing.Keyword("all")
			| pyparsing.StringEnd())
		return self.swallowCommand + selector
	
	def getCompletions(self, ctx, parts):
		if len(parts)!=2:
			return []
		return ["all", "failed"]

	def execute(self, ctx, criterion=None):
		if criterion=="all":
			toUpdate = metashelf.getNicksWithPrefix(ctx, "")
		else:
			toUpdate = metashelf.getNicksInPhases(ctx, [tapquery.QUEUED,
				tapquery.PENDING, tapquery.EXECUTING])
		for nick in toUpdate:
			try:
				job = metashelf.getJobByNick(ctx, nick)
				metashelf.updateJob(ctx, job, job.phase)
			except KeyError: # nick gone, don't worry
				pass
			except tapquery.Error: # probably the job is gone server-side
				metashelf.updateJob(ctx, job, "DESTROYED")


def _getFnameMatches(pathFragment):
	# a helper for Upload completion: return possible expansions for 
	# pathFragment. This is tricky since we need to know what items
	# are directories and which are files, hence plain glob won't work
	# Also, we need to work around a tokenization mismatch between
	# readline and us for quoted strings; hence, the mess with getting
	# the buffer all over again.
	res = []
	if pathFragment.startswith("~"):
		pathFragment = os.path.expanduser(pathFragment)

	for match in glob.iglob(pathFragment+"*"):
		if os.path.isdir(match):
			res.append('"%s/'%match.replace('"', '\"'))
		else:
			res.append('"%s" '%match.replace('"', '\"'))

	beforeScope = readline.get_line_buffer()[:readline.get_begidx()]
	# There's trouble with readline tokenization when there's beforeScope
	# ends with a blank and there is a double quote.  Since I don't want
	# to handle escaped dquotes (come on, people, keep your file names
	# remotely sane!), I give up when there's a backslash in beforeScope.
	# Really sorry about this mess.  Is there a way to install custom
	# tokenizers on readline?
	if beforeScope.endswith(" "):
		if '\\' in beforeScope:
			return ()
		quoteIdx = beforeScope.rfind('"')
		if quoteIdx!=-1:
			prefixLength = len(beforeScope[quoteIdx:])
			res = [s[prefixLength:] for s in res]
	
	return res


class Upload(commandbase.Command):
	clidoc = ('(result <nick>|samp|"local file"|URL) as <name> --'
		' adds an upload to the current job')
	longdoc = """
	The upload command allows you to temporarily ingest your own data or
	previous results into the server database.  Not all TAP servers
	support this.
	
	The data uploaded must be in VOTable format and preferably only
	contain a single table.

	You can upload a previous job's result by nickname (try ``upload result
	<Tab>``).  To upload a local file, put it in double quotes.  HTTP URLs
	can also be uploaded, but they must be accessible to the local host,
	since it is downloaded from the source server and uploaded to the 
	TAP server (this is because it is far more likely that the remote server
	cannot access a URL accessible to the client than vice versa).

	The special ``upload samp`` form will upload the last table sent to
	tapsh (or broadcast) by SAMP clients.  This is a convenient way to
	use data generated by other VO clients (e.g., VODesktop).

	You must give the uploaded table a name consisting of alphabetic
	characters and an underscore.  In your queries, you refer to the
	uploaded table as ``tap_upload.<tablename>``.  
	
	You can upload more than one file in this way for complex joins.
	"""

	class _JobResult(object):
		# A helper class for CL parsing: a job result
		def __init__(self, nick):
			self.nick = nick

		def getUploadable(self, ctx):
			return metashelf.getJobByNick(ctx, self.nick).getResultURL()


	class _LocalFile(object):
		# A helper class for cl parsing: a local file
		def __init__(self, fName):
			self.fName = fName.strip('"')

		def getUploadable(self, ctx):
			return open(self.fName)


	class _SAMPFile(object):
		# Helper class for cl parsing: the last table broadcast by SAMP
		def getUploadable(self, ctx):
			if ctx.sampTable is None:
				raise common.FailedCommand("No SAMP table yet.")
			# We download the stuff and upload it to the server rather than
			# just passing on the URL since the URL might not be accessible
			# from the server.
			try:
				f = urllib.urlopen(ctx.sampTable)
			except IOError:
				raise common.FailedCommand("SAMP table appears to be gone.")
			return f

	
	class _URL(object):
		# Helper class for cl parsing: a URL
		def __init__(self, url):
			self.url = url

		def getUploadable(self, ctx):
			return self.url


	def _getCLIGrammar(self):
		resultSpec = (pyparsing.CaselessKeyword("result")
			+ self.nickSymbol).setParseAction(
				lambda s,p,t: self._JobResult(t[1]))
		localFile = common.quotedString.copy().setParseAction(
			lambda s, p, t: self._LocalFile(t[0]))
		localFile.setName("local file")
		sampSpec = pyparsing.CaselessKeyword("samp")
		sampSpec.setParseAction(
			lambda s, p, t: self._SAMPFile())
		as_ = pyparsing.CaselessKeyword("as")
		urlSpec = pyparsing.Regex("http://[^ ]+")
		urlSpec.setParseAction(
			lambda s, p, t: self._URL(t[0]))
		urlSpec.setName("http url")
		tableName = pyparsing.Word(pyparsing.alphas+"_")
		tableName.setName("table name")
		return (self.swallowCommand 
			+ ( resultSpec | sampSpec | urlSpec | localFile )
			+ pyparsing.Suppress(as_)
			+ tableName)

	def _getNonFileFirstArgs(self, ctx):
		res = ["result ", "http://"]
		if ctx.sampTable:
			res.append("samp ")
		return res
	
	def _completeFirstArg(self, ctx, parts):
		if parts[-1]:
			if parts[-1].startswith('"'):
				return _getFnameMatches(parts[1][1:])
			else:
				return common.getMatching(parts[-1], self._getNonFileFirstArgs(ctx))
		return self._getNonFileFirstArgs(ctx)

	def _completeTail(self, ctx, part, tailLength):
		if tailLength==0:
			return ["as "]
		elif tailLength==1:
			return ["uploaded"]
		else:
			return []

	def _completeForResult(self, ctx, parts):
		if len(parts)==3:
			return [s+" " for s in metashelf.getNicksWithPrefix(ctx, parts[-1])]
		else:
			return self._completeTail(ctx, parts, len(parts)-4)

	def _completeForLocalFile(self, ctx, parts):
		return self._completeTail(ctx, parts, len(parts)-3)

	def getCompletions(self, ctx, parts):
		numParts = len(parts)
		if numParts<2:
			return []
		elif numParts==2:
			return self._completeFirstArg(ctx, parts)

		# Remaining completion depends what we are completing (result or file)
		if parts[1].lower()=="result":
			return self._completeForResult(ctx, parts)
		else:
			return self._completeForLocalFile(ctx, parts)
	
	def execute(self, ctx, toUpload, tableName):
		if ctx.currentJob is None:
			raise common.FailedCommand("No current job")
		if ctx.currentJob.lastPhase!=tapquery.PENDING:
			raise common.FailedCommand("Uploads only supported for PENDING jobs.")
		ctx.currentJob.addUpload(tableName, toUpload.getUploadable(ctx))


class Exec(commandbase.Command):
	clidoc = "<file name> -- creates a query from the content of file name"
	longdoc = """
	exec lets you prepare and edit queries in your favourite editor.
	"""
	def execute(self, ctx, inputName):
		try:
			with open(inputName[1:-1]) as f:
				ctx.createJob(f.read())
		except IOError, msg:
			raise common.FailedCommand("Could not make job from file: %s"%msg)
	
	def _getCLIGrammar(self):
		localFile = common.quotedString.copy()
		localFile.setName("input name")
		return self.swallowCommand + localFile

	def getCompletions(self, ctx, parts):
		if " ".join(parts[1:]):
			return _getFnameMatches(" ".join(parts[1:])[1:])
		else:
			return ['"']


class KeepFor(commandbase.Command):
	clidoc = ("<num> -- ask the server to keep the job for another <num> days")
	longdoc = """
	TAP servers only keep jobs around for a limited period.  To find out
	when they are scheduled for destruction, just the job command.

	The keepfor command requests to change that destruction time to <num>
	days in the future.  TAP servers are free to ignore or modify your
	request, which is why the command outputs the new destruction time.
	"""
	
	def _getCLIGrammar(self):
		return (self.swallowCommand 
			+ self.integerSymbol)
	
	def execute(self, ctx, numDays):
		if ctx.currentJob is None:
			raise common.FailedCommand("No current job")
		destDate = datetime.datetime.utcnow()+datetime.timedelta(days=numDays)
		ctx.currentJob.destruction = destDate
		common.output("Destrucion of %s scheduled for %s."%(
			ctx.currentJob.nickname,
			ctx.currentJob.destruction))


class Limit(commandbase.Command):
	clidoc = ("<num> -- tell the server to let the job run for up to <num>"
		" seconds")
	longdoc = """
	TAP servers (usually) enforce limits on the execution time of queries,
	such that a job is aborted after, say, an hour or a day.  For
	long-running queries, that period may be too short.

	With the limit command, you can ask the server to raise (or lower)
	this time limit to the number of seconds specified in the argument.
	The server is free to discard or modify this request.  Therefore,
	the new time limit is printed by the command.
	"""
	
	def _getCLIGrammar(self):
		return (self.swallowCommand 
			+ pyparsing.Word("0123456789").addParseAction(lambda s,p,t: int(t[0])))
	
	def execute(self, ctx, numSecs):
		if ctx.currentJob is None:
			raise common.FailedCommand("No current job")
		ctx.currentJob.executionDuration = numSecs
		common.output("Job %s will be aborted after %s seconds"%(
			ctx.currentJob.nickname,
			ctx.currentJob.executionDuration))


class Error(commandbase.CommandWithNickArg):
	clidoc = "[<nick>] -- give error message of current or selected job"
	longdoc = """
	TAP servers give error messages under a special resource.  The
	error command retrieves that resource, tries to parse it as a
	VOTable and returns TAP error messages contained in that VOTable
	if successful.  Maformed responses will be printed verbatim.

	Without an argument, the error command shows the message for the
	current job, otherwise for the job specified using its nickname.

	The behavior of this command is unspecified if the job is not in
	the ERROR phase.
	"""

	def execute(self, ctx, nick=None):
		job = self.getJob(ctx, nick)
		common.output(job.getErrorFromServer())


class SetPar(commandbase.Command):
	clidoc = "<parName> <value> -- sets a remote parameter."
	longdoc = """
	Internally, TAP has a number of parameters.  You can set them using
	this command.  However, since most parameters are actually managed by
	other commands, you can break a lot here.  So, only use this if you
	know what you're doing.

	A useful example could be ``setPar FORMAT fits`` to ask a TAP
	server to return the result as a fits binary table.  However, such
	a result would then not work as an upload.
	"""
	def _getCLIGrammar(self):
		parName = pyparsing.Word(pyparsing.alphanums)
		parName.setName("parameter name")
		parValue = pyparsing.SkipTo(pyparsing.StringEnd(), include="True")
		parValue.setName("parameter value")
		return self.swallowCommand + parName + parValue

	def execute(self, ctx, key, value):
		if ctx.currentJob is None:
			raise common.FailedCommand("No current job.")
		ctx.currentJob.setParameter(key, value)

