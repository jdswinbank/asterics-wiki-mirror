"""
Basic definitions for commands
"""

from gavo import utils
from gavo.imp import pyparsing

from tapsh import common
from tapsh import metashelf


class Command(object):
	"""Something callable from tapsh's command line

	You must provide

	* clidoc -- a short string describing the command's action
	* longdoc -- longer documentation on the command
	* execute(ctx, ...) -- a function doing the action

	clidoc has to be of the form "<args> -- description".

	If execute takes no arguments but ctx, that's enough.  If you want
	arguments to be passed, define the _getCLIGrammar() method to
	return a pyparsing symbol (you could also override the parseCommandLine
	method, of course).  The parse result should, interpreted as a list,
	supply the additional arguments to execute.  The class has an attribute
	swallowCommand that is a good start for a grammar -- it just takes away
	the command word without a trace.

	If you accept arguments, it's a nice treat if you provide a completer
	function complete(ctx) -> list.  It will receive your arguments so far,
	blindly split at any whitespace and should return a list of possible
	expansions.

	Commands get instanciated exactly once at program startup, so
	if you need some preparations, you can do them in an argumentless
	__init__; you must call the parent class' __init__, though.
	"""
	clidoc = "Undocumented"
	longdoc = """
	No help available
	"""

	def __init__(self):
		self.cliGrammar = self._getCLIGrammar()

	swallowCommand = pyparsing.Suppress(pyparsing.Word(pyparsing.alphanums))
	swallowCommand.setName("command")
	nickSymbol = pyparsing.Word(pyparsing.alphas)
	nickSymbol.setName("job nickname")
	integerSymbol =  pyparsing.Word("0123456789").addParseAction(
		lambda s,p,t: int(t[0]))
	integerSymbol.setName("integer")

	def _getCLIGrammar(self):
		# default implementation: command, then nothing.
		return self.swallowCommand
	
	def getCompletions(self, ctx, parts):
		return []

	def execute(self, ctx):
		raise common.FailedCommand("This command does not define an action")

	def parseCommandLine(self, commandLine):
		try:
			res = self.cliGrammar.parseString(commandLine, parseAll=True)
		except (pyparsing.ParseException, pyparsing.ParseSyntaxException), ex:
			raise common.FailedCommand("Syntax error at %s (%s)"%(
				ex.loc, ex.msg))
		return list(res)

	def getLongdoc(self):
		return self.clidoc+"\n"+utils.fixIndentation(self.longdoc, "", 1)

	def __call__(self, ctx, input):
		self.execute(ctx, *self.parseCommandLine(input))


class CommandWithNickArg(Command):
	"""A Command that takes either a nick id or nothing.
	"""
	clidoc = None  # just a base for others

	def _getCLIGrammar(self):
		return self.swallowCommand + pyparsing.Optional(self.nickSymbol)

	def getCompletions(self, ctx, parts):
		if len(parts)!=2:
			return []
		return metashelf.getNicksWithPrefix(ctx, parts[-1])
	
	def getJob(self, ctx, nick):
		if nick is None:
			if ctx.currentJob is None:
				raise common.FailedCommand("No current job")
			return ctx.currentJob
		else:
			try:
				return metashelf.getJobByNick(ctx, nick)
			except KeyError:
				raise common.FailedCommand("No such job known: '%s' (try ls)."%nick)


class CommandWithServerArg(Command):
	"""A Command that takes nothing or a service id.
	"""
	def _getCLIGrammar(self):
		ivoId = pyparsing.Word(pyparsing.alphanums+"_:/-%.")
		ivoId.setName("TAP server id")
		return self.swallowCommand + (ivoId | pyparsing.StringEnd())

	def getCompletions(self, ctx, parts):
		if len(parts)!=2:
			return []
		return [s[0] for s in metashelf.getServersForPrefix(parts[-1])]


class Commands(object):
	"""the commands available in the repl.
	"""
	def __init__(self, commandModules):
		self.commands = {}
		for mod in commandModules:
			for name in dir(mod):
				obj = getattr(mod, name)
				if isinstance(obj, type) and issubclass(obj, Command):
					name = obj.__name__.lower()
					self.commands[name] = obj()
	
	def __iter__(self):
		return iter(self.commands)

	def iteritems(self):
		return self.commands.iteritems()

	def getCommand(self, token):
		token = token.lower()
		if token in self.commands:
			return self.commands[token]
		raise common.FailedCommand("No command '%s' known"%token)

	def printReference(self):
		"""writes an RST-fragment containing docs my commands to stdout.
		"""
		frags = []
		for cmdName, cmd in self.commands.iteritems():
			head = "%s command"%cmdName
			frag = [head, "'"*len(head)+"\n"]
			frag.append(cmdName+" "+cmd.getLongdoc())
			frags.append((cmdName, "\n".join(frag)))
		frags.sort()	
		print "\n\n".join(f[1] for f in frags).replace("|", "\\|")
		print ".. END COMMAND REFERENCE"
