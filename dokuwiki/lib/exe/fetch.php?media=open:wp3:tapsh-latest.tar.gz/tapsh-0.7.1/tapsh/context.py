"""
The context object, the main state-bearing thing within tapsh.
"""

from __future__ import with_statement

import re
import readline

from tapsh import common
from tapsh import httpinter
from tapsh import metashelf
from tapsh import sampy
from tapsh import tapserver


SAMP_LOG_LEVEL = sampy.SAMPLog.ERROR


class Completer(object):
	"""a completer for readline.
	"""
	def __init__(self, ctx):
		# This creates a reference cycle.  If at some point this becomes
		# bothersome, let's go weakref.
		self.ctx = ctx
		self.matches = ()
		readline.parse_and_bind("tab: complete")
		readline.parse_and_bind('"\em": "1=CONTAINS(POINT(\'ICRS\', ra1, dec1),'
			' CIRCLE(\'ICRS\', ra2, dec2, radius))"')
		readline.set_completer_delims(" \t")
		readline.set_completer(self)

	def _computeMatches(self, curWord):
		parts = common.tokenizeInput(readline.get_line_buffer().lstrip())
		if len(parts)<2: # no (complete) command yet
			return [w+" " for w in self.ctx.commands if w.startswith(curWord)]

		else: # delegate to command if parts[0] selects a valid one.
			try:
				cmd = self.ctx.commands.getCommand(parts[0])
			except common.FailedCommand:  # bad command -- ignore for completion
				return ()
			return cmd.getCompletions(self.ctx, parts)

	def __call__(self, curWord, state):
		if state==0: # compute matches on first call
			try:
				self.matches = self._computeMatches(curWord)
			except: # don't fail silently here
				import traceback
				traceback.print_exc()
				return ()

		try:
			return self.matches[state]
		except IndexError: # matches exhausted, clear for next expansion
			self.matches = ()
		return None


class Context(object):
	"""an object containing many aspects of the current session.
	"""
	# non-None exitValues will terminate the rep loop.
	exitValue = None
	currentJob = None
	currentServer = None
	possibleMatches = ()
	# last VOTable broadcast
	sampTable = None
	# the SAMP client
	samp = None
	# a SAMP hub (if started)
	hub = None
	# the base URL of our internal server
	tapshURLBase = None

	def __init__(self, commands, opts):
		self.scriptFile = opts.scriptFile
		self._fillTables()
		self.commands = commands
		self.completer = Completer(self)
		self._recoverState()
		self.tapshURLBase = httpinter.startServer(self)
		if opts.runSAMP:
			try:
				self._initSAMP()
			except Exception, msg: # don't die because of SAMP
				common.outputError("SAMP setup failed (%s) -- interprocess"
					" communication will probably not work"%str(msg))
		self.echoInput = opts.echoInput

	def _fillTables(self):
		"""inits some database tables if necessary.
		"""
		if metashelf.getServersForPrefix("")==[]: 
			# no servers?  init from data center
			metashelf.refreshServerList()

	def _recoverState(self):
		curSrv = metashelf.getStateItem("currentServer")
		if curSrv:
			try:
				self.setServer(curSrv)
			except KeyError: # Bad server, can't fix
				raise

		jobNick = metashelf.getStateItem("currentJob")
		if jobNick:
			try:
				self.currentJob = metashelf.getJobByNick(self, jobNick)
			except KeyError: # last current job has vanished
				pass

	def _initSAMP(self):
		clientMetadata = {
			"samp.name": "TAPsh", 
			"samp.description.text": "TAP shell"}
		if self.tapshURLBase:
			clientMetadata["samp.icon.url"] = self.tapshURLBase+"/tapsh_icon.png"

		self.samp = sampy.SAMPIntegratedClient(metadata=clientMetadata)
		with common.progress("Connecting to SAMP hub...", failureOk=True):
			try:
				self.samp.connect()
			except sampy.SAMPHubError:
				self.hub = _startHub(self.tapshURLBase)
				self.samp.connect()
		self.samp.bindReceiveCall("table.load.votable",
			self._setSAMPTable)
		
	def _setSAMPTable(self, private_key, sender_id, msg_id, mtype, params, extra):
		# callback for SAMP load table -- just memorize the URL for later use.
		self.sampTable = params.get("url")
		self.samp.ereply(msg_id, sampy.SAMP_STATUS_OK, result={})

	def setServer(self, ivoId):
		"""makes serverId the current server.

		This function raises a KeyError if the server id is not known.
		"""
		try:
			self.currentServer = tapserver.TAPServer(ivoId,
				metashelf.getURLForServer(ivoId))
		except KeyError:
			# last server is gone
			self.currentServer = None
			raise

	def createJob(self, query):
		"""makes a new current job from query.
		"""
		if not self.currentServer:
			raise common.FailedCommand("Cannot create query since no server"
				" is selected (try server<TAB>).")
		self.currentJob = metashelf.registerJob(self,
			self.currentServer.createJob(query))

	def saveState(self):
		if self.currentServer:
			metashelf.setStateItem(
				"currentServer", self.currentServer.ivoId)
		metashelf.setStateItem("currentJob", 
			self.currentJob and self.currentJob.nickname)
	
	def cleanup(self):
		"""cleans up environment (kill SAMP, etc.)

		This method should be called if at all possible before application
		exit.
		"""
		httpinter.stopServer(self)
		if self.samp:
			try:
				self.samp.disconnect()
			except sampy.SAMPClientError: # Disconnection failed, never mind.
				pass
		if self.hub:
			with common.progress("Shutting down SAMP Hub..."):
				self.hub.stop()


def _startHub(tapshURLBase):
	hubMetadata = {
		'samp.name': "tapsh builtin hub",}
	if tapshURLBase:
		hubMetadata["samp.icon.url"] = tapshURLBase+"/sampy_icon.png"
	hub = sampy.SAMPHubServer(additionalMetadata=hubMetadata,
		log=sampy.SAMPLog(level=SAMP_LOG_LEVEL))
	hub.start()
	return hub
