"""
Local storage for server and job metadata, file based.

See shelving.py for more information.
"""

from __future__ import with_statement

import cPickle as pickle
import datetime
import dumbdbm
import glob
import os

from gavo import votable
from tapsh import common
from tapsh import shelving


JOBS_DIR = os.path.join(common.TAPSH_DIR, "jobs")
SERVERS_FILE = os.path.join(common.TAPSH_DIR, "servers.pickle")

_TIME_FORMAT = "%Y-%m-%dT%H:%M:%S"


class JobMetaMalformed(Exception):
	pass


# This module keeps quite a bit of global state that metashelf_sqlite
# more or less has in the DB.  We keep all of this in the _STATE class
# to make it easy to see where global state is manipulated.
#
# Most of this is initialized in ensureStorage.
class _STATE(object):
	# a dbm containing miscellaneous state info
	statedb = None

	# a list of (ivoId, accessURL) pairs
	serverList = None


def ensureStorage():
	# the tapsh dir is already created by main.ensureEnvironment
	if not os.path.isdir(JOBS_DIR):
		os.mkdir(JOBS_DIR)
	_STATE.statedb = dumbdbm.open(os.path.join(common.TAPSH_DIR, "state"), "c")

	if not os.path.exists(SERVERS_FILE):
		refreshServerList()
	try:
		with open(SERVERS_FILE) as f:
			_STATE.serverList = pickle.load(f)
	except (IOError, EOFError):
		refreshServerList()


def addServer(id, accessURL):
	_STATE.serverList.append((id, accessURL))


def saveServerList():
	with open(SERVERS_FILE, "w") as f:
		pickle.dump(_STATE.serverList, f)


def refreshServerList():
	"""obtains a list of TAP servers from GAVO's GloTS service.
	"""
	with common.progress("Refreshing TAP server list from GAVO Data Center..."):
		_STATE.serverList = shelving.getServerListFromNet()
		saveServerList()


def getURLForServer(ivoId):
	"""returns the accessURL of the server with ivoId (or raises a KeyError).
	"""
	for curId, curURL in _STATE.serverList:
		if curId.lower()==ivoId.lower():
			return curURL
	raise KeyError(ivoId)


def getServersForPrefix(prefix):
	"""returns a list of ivo-ids of TAP servers starting with prefix.
	"""
	prefix = prefix.lower()
	servers = []
	for curId, accessURL in _STATE.serverList:
		if curId.lower().startswith(prefix):
			servers.append((curId, accessURL))
	return servers


def getStateItem(key):
	"""returns the value of the misc state item key, returning None
	for non-existing keys.
	"""
	return _STATE.statedb.get(key, None)


def setStateItem(key, value):
	"""sets the misc state item key to value.
	"""
	if value is None:
		try:
			del _STATE.statedb[key]
		except KeyError:
			pass
	else:
		_STATE.statedb[key] = value
	_STATE.statedb.sync()


def _serializeJobMeta(meta):
	return "%s\n%s\n%s\n%s\n%s\n"%(
		meta["nickname"], 
		meta["jobId"], 
		meta["endpointURL"], 
		meta["lastPhase"], 
		meta["lastUpdate"].strftime(_TIME_FORMAT))


def _getMetaFromJob(job):
	return {
		"nickname": job.nickname,
		"jobId": job.jobId,
		"endpointURL": job.endpointURL,
		"lastPhase": job.lastPhase,
		"lastUpdate": job.lastUpdate}


def _persistMeta(meta):
	with open(os.path.join(JOBS_DIR, meta["nickname"]), "w") as f:
		f.write(_serializeJobMeta(meta))


def _persistJob(job):
	_persistMeta(_getMetaFromJob(job))


def _parseJobMeta(srcFile):
	res = {}
	try:
		parts = srcFile.read().strip().split("\n")
		if len(parts)!=5:
			raise ValueError("Malformed job metafile")
		res["jobId"], res["endpointURL"] = parts[1:3]
		res["nickname"], res["lastPhase"] = parts[0], parts[3]
		res["lastUpdate"] = datetime.datetime.strptime(
			parts[4], _TIME_FORMAT)
	except (ValueError, IndexError):
		raise JobMetaMalformed(
			"Bad meta from %s -- please fix or remove manually."%srcFile.name)
	return res


def _makeJobFromMeta(meta):
	job = votable.ADQLTAPJob(meta["endpointURL"], jobId=meta["jobId"])
	job.nickname = meta["nickname"]
	job.lastPhase = meta["lastPhase"]
	job.lastUpdate = meta["lastUpdate"]
	return job


def _iterJobMeta():
	for fName in os.listdir(JOBS_DIR):
		try:
			with open(os.path.join(JOBS_DIR, fName)) as f:
				yield _parseJobMeta(f)
		except JobMetaMalformed:
			pass


def registerJob(ctx, job):
	"""registers an ADQLTAPJob in the jobs table.

	The job object receives an additional attribute, nickname.

	This could race if multiple instance of tapsh are trying to create
	jobs at the same time.  If you don't like this, use the sqlite
	metashelf implementation.
	"""
	while True:
		nick = shelving.makeNick()
		destName = os.path.join(JOBS_DIR, nick)
		if not os.path.exists(destName):
			break

	with open(destName, "w") as f:
		job.nickname = nick
		job.lastPhase = "PENDING"
		job.lastUpdate = datetime.datetime.utcnow()
		f.write(_serializeJobMeta(_getMetaFromJob(job)))
	
	return job


def getJobByNick(ctx, nick):
	try:
		with open(os.path.join(JOBS_DIR, nick)) as f:
			return _makeJobFromMeta(_parseJobMeta(f))
	except IOError:
		raise KeyError(nick)


def getNicksInPhases(ctx, phaseSet):
	for rec in _iterJobMeta():
		if rec["lastPhase"] in phaseSet:
			yield rec["nickname"]


def updateJob(ctx, job, phase):
	job.lastPhase = phase
	job.lastUpdate = datetime.datetime.utcnow()
	_persistJob(job)


def renameJob(ctx, oldName, newName):
	destName = os.path.join(JOBS_DIR, newName)
	os.rename(os.path.join(JOBS_DIR, oldName), destName)
	with open(destName) as f:
		meta = _parseJobMeta(f)
	meta["nickname"] = newName
	_persistMeta(meta)


def removeJob(ctx, job):
	os.unlink(os.path.join(JOBS_DIR, job.nickname))


def getNicksWithPrefix(ctx, prefix):
	return [os.path.basename(n)
		for n in glob.glob(os.path.join(JOBS_DIR, prefix+"*"))]


def iterJobs(ctx):
	for meta in _iterJobMeta():
		yield _makeJobFromMeta(meta)
