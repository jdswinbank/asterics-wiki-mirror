"""
A little built-in HTTP server for delivering some files (and possibly more).
"""

from __future__ import with_statement

import BaseHTTPServer
import os
import select
import socket
import threading
import urllib
from cStringIO import StringIO

import pkg_resources

from gavo import utils

BASE_TEMPLATE = """
	<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"'
		' "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>
<title>%%(title)s</title>
</head>
<body>
<h1>%%(title)s</h1>
%(preContent)s
%%(content)s
%(postContent)s
</body>
</html>
"""


ERROR_TEMPLATE = BASE_TEMPLATE%{
		"headMaterial": "",
		"preContent": "",
		"postContent": "",
	}


class Resource(object):
	"""Something that is delivered by the web server.

	Resources have the attributes
	* contentType
	* httpStatus,

	and a method open() -> file-like object
	"""
	contentType = "application/octet-stream"
	httpStatus = 200

	def open(self):
		raise NotImplementedError("%s resources cannot be delivered"%
			self.__class__.__name)


class TextResource(Resource):
	"""A resource containing unicode text.
	"""
	contentType = "text/html;charset=UTF-8"

	def __init__(self, content):
		if isinstance(content, unicode):
			self.content = content.encode("utf8")
		else:
			self.content = content
	
	def open(self):
		return StringIO(self.content)


class ErrorResource(TextResource):
	"""An error message, complete with an HTTP status code.
	"""
	def __init__(self, status, msg):
		self.httpStatus = status
		TextResource.__init__(self, ERROR_TEMPLATE%{
				"title": "tapsh http server error",
				"content": msg,
			})


class PackageFileResource(Resource):
	"""A file to be delivered as-is from our package resources.
	"""
	_cache = None

	def __init__(self, pkgPath, contentType):
		self.pkgPath, self.contentType = pkgPath, contentType
	
	def open(self):
		if self._cache is None:
			return pkg_resources.resource_stream('tapsh', self.pkgPath)
		else:
			return StringIO(self._cache)

	def cacheData(self):
		self._cache = pkg_resources.resource_stream('tapsh', self.pkgPath).read()


RESOURCES = {
		"/tapsh_icon.png":
			PackageFileResource("res/tapsh_icon.png", "image/png"),
		"/sampy_icon.png":
			PackageFileResource("res/sampy_icon.png", "image/png"),
		"/test.txt": TextResource("lorem ipsum... "*10),}


class InternalServerHandler(BaseHTTPServer.BaseHTTPRequestHandler):
	"""The handler for the HTTP server.

	For now, we just have a mapping of "known resources" and do a 404 for
	all others.
	"""

	def _serveResource(self, res):
		self.send_response(res.httpStatus)
		self.send_header("Content-type", res.contentType)
		self.end_headers()
		inF = res.open()
		utils.cat(inF, self.wfile)
		inF.close()
		self.wfile.close()

	def _getResource(self):
		try:
			return RESOURCES[self.path]
		except KeyError:
			return ErrorResource(404, "Resource not found")

	def do_GET(self):
		try:
			self._serveResource(self._getResource())
		except Exception, msg:
			self._serveResource(
				ErrorResource(500, "Internal error %s: %s"%(
					msg.__class__.__name__, unicode(msg))))

	def log_message(self, *args):
		pass


def getHostAddress():
	"""returns an IP address for the current host.

	It does this by trying to connect to the GAVO DC and then checking
	what address the connection goes out on.  Any failures lead to a
	fallback to localhost.
	"""
	try:
		sock = socket.socket()
		try:
			sock.settimeout(0.5)
			sock.connect(("dc.zah.uni-heidelberg.de", 80))
			return sock.getsockname()[0]
		finally:
			sock.close()
	except Exception, ex:
		return "127.0.0.1"


if hasattr(os, "pipe"):
# cPython, at least
	class StoppableServer(BaseHTTPServer.HTTPServer):
		def __init__(self, serverAddress, handlerClass):
			self._stopperRead, self._stopperWrite = os.pipe()
			BaseHTTPServer.HTTPServer.__init__(self, serverAddress,
				handlerClass)

		def serve_forever(self):
			while True:
				r, w, e = select.select([self, self._stopperRead], [], [])
				if self in r:
					self.handle_request()
				if self._stopperRead in r:
					break
			os.close(self._stopperRead)

		def startServer(self):
			self.thread = threading.Thread(target=self.serve_forever)
			self.thread.setDaemon(True)
			self.thread.start()

		def stopServer(self):
			os.write(self._stopperWrite, "\n")
			self.thread.join(1)
else:
# jython has no os.pipe.  Since proper shutdown of the http server
# is more an aesthetic issue, we just forget about it and let the
# thread die
	class StoppableServer(BaseHTTPServer.HTTPServer):
		def __init__(self, serverAddress, handlerClass):
			BaseHTTPServer.HTTPServer.__init__(self, serverAddress,
				handlerClass)

		def startServer(self):
			self.thread = threading.Thread(target=self.serve_forever)
			self.thread.setDaemon(True)
			self.thread.start()

		def stopServer(self):
			pass


def startServer(ctx):
	"""starts a thread running an http server on some free port.
	"""
	# Pull all resources data into memory before threading off
	# It seeems at least in jython 2.5.2 with about contemporary
	# pkg_resources, it's not thread-safe to pull in resources from
	# jars.
	for res in RESOURCES.itervalues():
		if isinstance(res, PackageFileResource):
			res.cacheData()

	for portNumber in range(6700, 6750):
		# find a usable port
		try:
			address = ("", portNumber)
			server = StoppableServer(address, InternalServerHandler)
		except socket.error:
			pass
		else:
			break
	else:
		# Looks like the system doesn't let us open a socket.
		# So far, no important functionality is affected, so keep quiet about it.
		return None

	server.startServer()
	ctx.httpServer = server

	return "http://%s:%s"%(getHostAddress(), portNumber)


def stopServer(ctx):
	if hasattr(ctx, "httpServer"):
		ctx.httpServer.stopServer()


if __name__=="__main__":
	startServer(None)
