"""
Local storage for server and job metadata, sqlite-based.

See shelving.py for more information.
"""

from __future__ import with_statement

import datetime
import re
import os

from gavo import utils
from gavo import votable

from tapsh import common
from tapsh import dbinter
from tapsh import shelving


DSN = os.path.join(common.TAPSH_DIR, "metashelf")


# We have a single global sqlite connection for maintaining metadata;
# it is opened by the ensureStorage function
_CONN = None


class ServerTable(dbinter.TableDef):
	"""the table to maintain the persistent server list.

	(the context keeps an in-memory copy of this).
	"""
	c_000_ivoid = 'TEXT'
	c_010_accessURL = 'TEXT'
_servers = ServerTable("servers")


class StateTable(dbinter.TableDef):
	"""a table just keeping key-value pairs for tapsh state management.
	"""
	c_000_key = 'TEXT'
	c_010_value = 'TEXT'
_state = StateTable("state")


class JobsTable(dbinter.TableDef):
	"""the table of jobs currently "under surveillance".
	"""
	c_000_nickname = 'TEXT PRIMARY KEY' # local nickname (locally unique!)
	c_010_jobId = 'TEXT NOT NULL'       # remote job id
	c_020_endpointURL = 'TEXT NOT NULL' # services's URL
	c_030_lastphase = 'TEXT NOT NULL'   # last known phase
	c_040_lastupdate = 'TIMESTAMP NOT NULL'  # last update of the phase

_jobs = JobsTable("jobs")


def ensureStorage():
	global _CONN
	_CONN = dbinter.getConnection(DSN)
	dbinter.ensureTables(_CONN,
		utils.iterDerivedObjects(dbinter.TableDef, globals().values()))
	_CONN.commit()


def refreshServerList():
	with common.progress("Refreshing TAP server list from GAVO Data Center..."):
		serverList = shelving.getServerListFromNet()
		_CONN.executemany("INSERT INTO servers (ivoid, accessURL)"
			" VALUES (?,?)", serverList)


def getURLForServer(ivoId):
	"""returns the accessURL of the server with ivoId (or raises a KeyError).
	"""
	res = list(_CONN.execute("SELECT accessURL FROM servers WHERE ivoid=?",
		(ivoId,)))
	if not res:
		raise KeyError(ivoId)
	return res[0][0]


def getServersForPrefix(prefix):
	return list(_CONN.execute("SELECT ivoId FROM servers WHERE ivoid LIKE ?",
		(prefix+'%',)))


def getStateItem(key):
	res = list(_CONN.execute("SELECT value FROM state WHERE key=?", (key,)))
	if res:
		return res[0][0]
	else:
		return None


def setStateItem(key, value):
	cursor = _CONN.cursor()
	cursor.execute("DELETE FROM state WHERE key=?", (key,))
	cursor.execute("INSERT INTO state (key, value) VALUES (?,?)",
		(key, value))
	_CONN.commit()


def registerJob(ctx, job):
	"""registers an ADQLTAPJob in the jobs table.

	The job object receives an additional attribute, nickname.
	"""
	cursor = _CONN.cursor()
	while True:
		nick = shelving.makeNick()
		try:
			cursor.execute("INSERT INTO jobs (nickname, jobId, endpointURL,"
				" lastphase, lastupdate) VALUES (?, ?, ?, ?, ?)",
				(nick, job.jobId, job.endpointURL, 'PENDING', 
					datetime.datetime.utcnow()))
		except dbinter.IntegrityError:  # nick already taken, try next
			pass
		else:  # nick has been free
			break
	_CONN.commit()
	job.nickname = nick
	job.lastPhase = "PENDING"
	return job


def _makeJobFromRec(rec):
	"""returns an ADQLTAPJob from a jobs table row.
	"""
	nickname, jobId, endpointURL, lastPhase, lastUpdate = rec
	job = votable.ADQLTAPJob(endpointURL, jobId=jobId)
	job.nickname = nickname
	job.lastPhase = lastPhase
	job.lastUpdate = lastUpdate
	return job


def getJobByNick(ctx, nick):
	"""returns an ADQLTAPJob object for a nickname.

	The function raises a KeyError if the nickname is unknown.
	"""
	res = list(_CONN.execute(
		"SELECT * FROM jobs WHERE nickname=?", (nick,)))
	if not res:
		raise KeyError(nick)
	return _makeJobFromRec(res[0])


def getNicksInPhases(ctx, phaseSet):
	# I'm not bothering with a set adapter for pysqlite -- phases are
	# controlled vocabulary anyway
	nonAlphas = re.compile("[^A-Z]+")
	setLiteral = '(%s)'%(
		", ".join("'%s'"%nonAlphas.sub("", p) for p in phaseSet))
	return [row[0] for row in _CONN.execute(
		"SELECT nickname FROM jobs WHERE lastphase IN %s"%setLiteral)]


def updateJob(ctx, job, phase):
	"""updates job's job table entry to be phase.
	"""
	_CONN.execute(
		"UPDATE jobs SET lastphase=?, lastUpdate=? WHERE nickname=?",
		(phase, datetime.datetime.utcnow(), job.nickname))
	_CONN.commit()


def renameJob(ctx, oldName, newName):
	_CONN.execute("UPDATE jobs SET nickname=? where nickname=?",
			(newName, ctx.currentJob.nickname))
	_CONN.commit()


def removeJob(ctx, job):
	"""removes the job from our tables (but does not otherwise touch it).
	"""
	_CONN.execute("DELETE FROM jobs WHERE nickname=?", (job.nickname,))
	_CONN.commit()


def getNicksWithPrefix(ctx, prefix):
	"""returns a list of job nicks starting with prefix.
	"""
	return list(
		row[0] for row in _CONN.execute(
			"SELECT nickname FROM jobs WHERE nickname LIKE ? ORDER BY nickname",
			(prefix+'%',)))


def iterJobs(ctx):
	"""iterates over ADQLTAPJobs for all known jobs.
	"""
	for rec in _CONN.execute("SELECT * FROM jobs"):
		yield _makeJobFromRec(rec)

