"""
A thin wrapper around sqlite to manage tables.
"""

import datetime
import re
try:
	import sqlite3 as sqlite
	from sqlite3 import IntegrityError
except ImportError:
	from pysqlite2 import dbapi2 as sqlite
	from pysqlite2.dbapi2 import IntegrityError


class TableDef(object):
	"""a definition of a table in an SQLite DB.

	The schema is defined in attributes in c_nnn_whatever names, post
	creation commands in attributes using pc_nnn_whatever names.  All
	this is to make inheritance useful for these table defs.

	Attributes include:

	* name -- the table name
	* schema -- a list of column name, column type pairs
	* columns -- a list of the column names
	"""
	def __init__(self, name):
		self.name = name
		self.schema = self._makeSchema()
		self.columns = [n for n, t in self.schema]

	_toNameRE = re.compile(r"^c_\d+_(.*)")

	def _makeSchema(self):
		return [(mat.group(1), getattr(self, mat.group())) 
		 	for mat in (self._toNameRE.match(name) 
				for name in sorted(dir(self)))
			if mat]

	def _iterPostCreateStatements(self):
		for cmdAttr in (s for s in sorted(dir(self)) if s.startswith("pc_")):
			yield getattr(self, cmdAttr)

	def iterBuildStatements(self):
		macros = self.__dict__.copy()
		macros["ddl"] = ", ".join("%s %s"%t for t in self.schema)
		yield "CREATE TABLE IF NOT EXISTS %(name)s (%(ddl)s)"%macros
		for statement in self._iterPostCreateStatements():
			yield statement%macros


def ensureTable(conn, tableDef):
	"""makes sure the TableDef instance tableDef exists on the database.
	"""
	curs = conn.cursor()
	for stmt in tableDef.iterBuildStatements():
		curs.execute(stmt)
	curs.close()


def ensureTables(conn, tables):
	"""creates tables if necessary.

	tables is a sequence of TableDef objects.
	"""
	for tableDef in tables:
		ensureTable(conn, tableDef)


def _convertTime(s):
	return datetime.time(*time.strptime(s, "%H:%M")[3:5])
sqlite.register_converter("TIME", _convertTime)
def _adaptTime(t):
	return t.strftime("%H:%M")
sqlite.register_adapter(datetime.time, _adaptTime)


def _convertBool(s):
	return bool(int(s))
sqlite.register_converter("BOOL", _convertBool)
def _adaptBool(t):
	return int(t)
sqlite.register_adapter(bool, _adaptBool)


def getConnection(dsn):
	return sqlite.connect(dsn,
		detect_types=sqlite.PARSE_DECLTYPES|sqlite.PARSE_COLNAMES)
