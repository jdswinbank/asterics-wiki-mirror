"""
The TAP shell.  The code actually running starts in tapsh.main.
"""
