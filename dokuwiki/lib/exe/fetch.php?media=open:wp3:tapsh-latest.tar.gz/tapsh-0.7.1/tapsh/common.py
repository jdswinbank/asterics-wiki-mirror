"""
Helpers and such for the TAP shell.

This is a bit of a mixed bag; if a "chapter" becomes too long, consider
making it into a module.
"""

import os
import sys
import traceback
import urlparse
from contextlib import contextmanager

from gavo.imp import pyparsing


VERSION = "0.7.1"

# no trailing slash here
GLOTS_BASE = "http://dc.g-vo.org/GloTS"

HOME=os.environ.get("HOME", os.environ.get("USERPROFILE"))

TAPSH_DIR = os.path.join(HOME, ".tapsh")

# are we running on a terminal?  (this is set early on by main and
# is used by many output routines to suppress "interactive" stuff when
# I/O redirection is in place)
ON_TERMINAL = True

class FatalError(Exception):
	"""is raised when a fatal error occurs.  
	
	It is constructed with an explanatory message to be emitted when aborting
	the program.
	"""


class FailedCommand(Exception):
	"""is raised when a command fails but the repl should continue.

	It is constructed with the message to be exposed to the user.
	"""


#################### Completer helpers

# use the following whenever you need a quoted string (this is what the
# completer's tokenizer uses, and it would be confusing to have
# more than one convention here).
quotedString = pyparsing.QuotedString(quoteChar='"', escChar="\\",
	unquoteResults=False)
quotedString.setName("string in double quotes")

def _getTokenizerGrammar():
	# a helper for tokenizeInput (see there)
	token = ( quotedString
		| pyparsing.Regex(r'[^\s"]+') )
	halfQuotedString = pyparsing.Regex('".*')
	return (pyparsing.ZeroOrMore(token) 
		+ pyparsing.Optional(halfQuotedString)
		+ pyparsing.StringEnd())
_tokenizerGrammar = _getTokenizerGrammar()


def tokenizeInput(inLine):
	"""returns input line tokens.

	Tokens are separated by whitespace, except that quoted strings are
	single tokens.  Backslash-scaped quotes do not terminate a token.
	Single quotes make everything until EOL a single token.

	This function is used by the completer; the commands each have their
	own grammar/tokenization rules.
	"""
	res = list(_tokenizerGrammar.parseString(inLine))
	# pyparsing ignores trailing blanks, but we need them, so:
	if inLine.endswith(" "):
		res.append("")
	return res


def getMatching(prefix, itemList):
	if prefix is None:
		prefix = ""
	return sorted(s for s in itemList if s.startswith(prefix))


######################## output functions

@contextmanager
def progress(msg, failureOk=False):
	"""Outputs msg and "waits" until context manager exit, then "finishes".

	This is for informational messages of the "X in progress" type.
	"""
	if not ON_TERMINAL:
		yield None
	else:
		sys.stdout.write(msg)
		sys.stdout.flush()
		try:
			yield None
		except:
			sys.stdout.write(" failed.\n")
			if not failureOk:
				raise
			return
		sys.stdout.write(" done.\n")


def output(msg):
	"""outputs msg as "normal" command output.

	A linefeed is added to msg.
	"""
	sys.stdout.write(msg+"\n")


def outputInfo(msg):
	sys.stdout.write(msg+"\n")


def outputError(msg, dumpExc=False):
	"""outputs msg as an error message.

	The message is preceded by a traceback.
	"""
	if dumpExc:
		traceback.print_exc()
	sys.stdout.write("*** %s\n"%msg)


def formatJob(job):
	"""returns a string representation of an ADQLTAPJob annotated
	with nickname and lastPhase.

	Such jobs are returned by metashelf.getJobByNick or metashelf.iterJobs.
	"""
	parsed = urlparse.urlparse(job.endpointURL)
	return "%-10s %-8s %-20s %-10s %8s"%(
		job.nickname[:9], job.jobId[:7], parsed.netloc[:19],
			job.lastPhase[:9], job.lastUpdate.date().isoformat())

