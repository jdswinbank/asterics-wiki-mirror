"""
A switch module letting you select whether to store metadata in
in sqlite or in files.

See the docstring in tapsh.shelving
"""

from tapsh.shelving import *
from tapsh.metashelf_files import *
