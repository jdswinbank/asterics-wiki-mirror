from setuptools import setup, find_packages, Extension
import sys

sys.path = ["tapsh"]+sys.path
import common
codeVersion = common.VERSION


INSTALL_REQUIRES = ["gavoutils", "gavovot", "pysqlite"]
if len(sys.argv)>1 and sys.argv[1]=="develop":
	INSTALL_REQUIRES = []
DEPENDENCY_LINKS = ["http://vo.ari.uni-heidelberg.de/soft/dist"]


def _getDict(**kwargs):
	return kwargs


SETUP_ARGS = _getDict(
	name="tapsh",
	description="The TAP shell lets you query Virtual Observatory TAP services"
		" in the style of common database shells.",
	url="http://vo.ari.uni-heidelberg.de/soft",
	license="GPL",
	author="Markus Demleitner",
	author_email="gavo@ari.uni-heidelberg.de",
	version=codeVersion)

if __name__=="__main__":
	args = SETUP_ARGS.copy()

	args.update({
		"include_package_data": True,
		"install_requires": INSTALL_REQUIRES,
		"dependency_links": DEPENDENCY_LINKS,
		"packages": find_packages(),
		"entry_points": {
			'console_scripts': [
				'tapsh = tapsh.main:main',
			],}
		})

	setup(**args)
