default_app_config = 'django.contrib.staticfiles.apps.StaticFilesConfig'
