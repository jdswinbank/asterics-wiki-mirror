/* -------------------------------------------------------------------\
 * WARNING!\
 * This is a generated code! Do not modify this file.\
 * If you do, all changes will be lost when the file is re-generated.\
 * -------------------------------------------------------------------
*/

#include "ATMCommon.h"
#include <string>

ATM_NAMESPACE_BEGIN

std::string getVersion() {return "0.7.0";}

std::string getTag() {return "ATM-0_7_0";}

std::string getALMARelease() {return "ALMA-2015.2";}

ATM_NAMESPACE_END
